﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using QuanLyBanHang.Control;
using System.Data;
using System.Data.SqlClient;
using COMExcel = Microsoft.Office.Interop.Excel;

namespace QuanLyBanHang.View
{
    public partial class frmMain : Form
    {
        public frmMain()
        {
            InitializeComponent();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void tabPage4_Click(object sender, EventArgs e)
        {

        }

        //Bien toan cuc luu bang du lieu
        DataTable tblHH, tblHD, tblNV, tblNCC, tblCTHD, tblTKHH;
        //load dgv nhn vien
        public void LoadDataGridView_NV()
        {
            string sql;
            sql = "SELECT * FROm Nhanvien";
            tblNV = Functions.GetDataToTable(sql); //lấy dữ liệu
            dataGridView_nv.DataSource = tblNV;
            dataGridView_nv.Columns[0].HeaderText = "Mã nhân viên";
            dataGridView_nv.Columns[1].HeaderText = "Tên nhân viên";
            dataGridView_nv.Columns[2].HeaderText = "Giới tính";
            dataGridView_nv.Columns[3].HeaderText = "Ngày sinh";
            dataGridView_nv.Columns[4].HeaderText = "Điện thoại";
            dataGridView_nv.Columns[5].HeaderText = "Địa chỉ";
            dataGridView_nv.Columns[0].Width = 120;
            dataGridView_nv.Columns[1].Width = 200;
            dataGridView_nv.Columns[2].Width = 140;
            dataGridView_nv.Columns[3].Width = 150;
            dataGridView_nv.Columns[4].Width = 150;
            dataGridView_nv.Columns[5].Width = 150;
            dataGridView_nv.AllowUserToAddRows = false;
            dataGridView_nv.EditMode = DataGridViewEditMode.EditProgrammatically;
        }
        public void LoadDataGridView_NCC()
        {
            string sql;
            sql = "SELECT * From nhacungcap";
            tblNCC = Functions.GetDataToTable(sql); //lấy dữ liệu
            dataGridView_ncc.DataSource = tblNCC;
            dataGridView_ncc.Columns[0].HeaderText = "Mã nhà cung cấp";
            dataGridView_ncc.Columns[1].HeaderText = "Tên nhà cung cấp";
            dataGridView_ncc.Columns[2].HeaderText = "Địa chỉ";
            dataGridView_ncc.Columns[3].HeaderText = "Điện thoại";
            
            dataGridView_ncc.Columns[0].Width = 180;
            dataGridView_ncc.Columns[1].Width = 250;
            dataGridView_ncc.Columns[2].Width = 250;
            dataGridView_ncc.Columns[3].Width = 250;
         
            dataGridView_nv.AllowUserToAddRows = false;
            dataGridView_nv.EditMode = DataGridViewEditMode.EditProgrammatically;
        }
        //click nhà cc
        private void dataGridView_ncc_Click(object sender, EventArgs e)
        {
            if (btnThem_ncc.Enabled == false)
            {
                MessageBox.Show("Đang ở chế độ thêm mới!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtMaNCC_ncc.Focus();
                return;
            }
            if (tblNCC.Rows.Count == 0)
            {
                MessageBox.Show("Không có dữ liệu!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            txtMaNCC_ncc.Text = dataGridView_ncc.CurrentRow.Cells["Mancc"].Value.ToString();
            txtTenNCC_ncc.Text = dataGridView_ncc.CurrentRow.Cells["Tenncc"].Value.ToString();
            
            txtDiachi_ncc.Text = dataGridView_ncc.CurrentRow.Cells["Diachi"].Value.ToString();
            txtSDT_ncc.Text = dataGridView_ncc.CurrentRow.Cells["SDT"].Value.ToString();
            
            btnSua_ncc.Enabled = true;
            btnXoa_ncc.Enabled = true;
            //btnXoa.Enabled = true;
        }
        //click vào dgv
        private void dataGridView_nv_Click(object sender, EventArgs e)
        {
            if (btnThem_nv.Enabled == false)
            {
                MessageBox.Show("Đang ở chế độ thêm mới!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtManhanvien_nv.Focus();
                return;
            }
            if (tblNV.Rows.Count == 0)
            {
                MessageBox.Show("Không có dữ liệu!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            txtManhanvien_nv.Text = dataGridView_nv.CurrentRow.Cells["Manv"].Value.ToString();
            txtTennhanvien_nv.Text = dataGridView_nv.CurrentRow.Cells["Tennv"].Value.ToString();
            if (dataGridView_nv.CurrentRow.Cells["Gioitinh"].Value.ToString() == "Nam") chkGioitinh_nv.Checked = true;
            else chkGioitinh_nv.Checked = false;
            txtDiachi_nv.Text = dataGridView_nv.CurrentRow.Cells["Diachi"].Value.ToString();
            txtSDT_nv.Text = dataGridView_nv.CurrentRow.Cells["SDT"].Value.ToString();
            txtNgaysinh_nv.Text = dataGridView_nv.CurrentRow.Cells["Ngaysinh"].Value.ToString();
            btnSua_nv.Enabled = true;
            btnXoa_nv.Enabled = true;
            //btnXoa.Enabled = true;
        }

        //load datagridview cua hang hoa
        private void LoadDataGridView_HH()
        {
            string sql;
            sql = "SELECT * FROM HANGHOA";
            tblHH = Control.Functions.GetDataToTable(sql); //Đọc dữ liệu từ bảng
            dataGridView_hh.DataSource = tblHH; //Nguồn dữ liệu            
            dataGridView_hh.Columns[0].HeaderText = "Mã HH";
            dataGridView_hh.Columns[1].HeaderText = "Tên hàng hóa";
            dataGridView_hh.Columns[2].HeaderText = "Giá bán";
            dataGridView_hh.Columns[3].HeaderText = "Đơn vị tính";
            dataGridView_hh.Columns[4].HeaderText = "Nhà cung cấp";
            dataGridView_hh.Columns[5].HeaderText = "Số lượng";
            dataGridView_hh.Columns[6].HeaderText = "Giá nhập";
            dataGridView_hh.Columns[7].HeaderText = "Ghi chú";
            dataGridView_hh.Columns[0].Width = 100;
            dataGridView_hh.Columns[1].Width = 158;
            dataGridView_hh.Columns[2].Width = 118;
            dataGridView_hh.Columns[3].Width = 110;
            dataGridView_hh.Columns[4].Width = 98;
            dataGridView_hh.Columns[5].Width = 100;
            dataGridView_hh.Columns[6].Width = 118;
            dataGridView_hh.Columns[7].Width = 102;
            dataGridView_hh.AllowUserToAddRows = false; //Không cho người dùng thêm dữ liệu trực tiếp
            dataGridView_hh.EditMode = DataGridViewEditMode.EditProgrammatically; //Không cho sửa dữ liệu trực tiếp
        }
        //load datagridview cua hóa don
        private void LoadDataGridView_HD()
        {
            string sql;
            sql = "SELECT a.Mahh, b.Tenhh, a.Soluong, b.giaban, a.Giamgia,a.Thanhtien FROM chitiethoadon_ban AS a, Hanghoa AS b WHERE a.MaHD_Ban = N'" + txtMahoadon_hd.Text + "'and a.Mahh = b.Mahh";
            tblHD = Control.Functions.GetDataToTable(sql); //Đọc dữ liệu từ bảng
            dataGridView_hd.DataSource = tblHD; //Nguồn dữ liệu            
            dataGridView_hd.Columns[0].HeaderText = "Mã HH";
            dataGridView_hd.Columns[1].HeaderText = "Tên hàng hóa";
            dataGridView_hd.Columns[2].HeaderText = "Số lượng";
            dataGridView_hd.Columns[3].HeaderText = "Đơn giá";
            dataGridView_hd.Columns[4].HeaderText = "Giảm giá";
            dataGridView_hd.Columns[5].HeaderText = "Thành tiền";
          
            dataGridView_hd.Columns[0].Width = 90;
            dataGridView_hd.Columns[1].Width = 140;
            dataGridView_hd.Columns[2].Width = 80;
            dataGridView_hd.Columns[3].Width = 100;
            dataGridView_hd.Columns[4].Width = 80;
            dataGridView_hd.Columns[5].Width = 125;
            
       
            dataGridView_hh.AllowUserToAddRows = false; //Không cho người dùng thêm dữ liệu trực tiếp
            dataGridView_hh.EditMode = DataGridViewEditMode.EditProgrammatically; //Không cho sửa dữ liệu trực tiếp
        }


        


        private void frmMain_Load(object sender, EventArgs e)
        {
            //tabPage5.Enabled = false;
            Control.ConnectToSQL.Connect();
            if(FormLogin.ten == "nhanvien"){
                tabPage5.Enabled = false;
                btnXoa_hd.Enabled = false;
            }
            //MessageBox.Show("aa" +FormLogin.ten + "aa", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);

            btnLuu_hh.Enabled = false;
            btnLuu_hd.Enabled = false;
            btnLuu_nv.Enabled = false;
            btnLuu_ncc.Enabled = false;

            btnHuy_hh.Enabled = false;
            btnHuy_hd.Enabled = false;
            btnHuy_ncc.Enabled = false;
            btnHuy_nv.Enabled = false;


            btnSua_hh.Enabled = false;
            btnXoa_hd.Enabled = false;
            btnSua_ncc.Enabled = false;
            btnSua_nv.Enabled = false;


            btnXoa_hh.Enabled = false;
            btnXoa_hd.Enabled = false;
            btnXoa_ncc.Enabled = false;
            btnXoa_nv.Enabled = false;
            //tab nhân vien
            txtManhanvien_nv.Enabled = false;
            btnLuu_nv.Enabled = false;
            btnHuy_nv.Enabled = false;
            LoadDataGridView_NV();
            //tab nha cung cap
            txtMaNCC_ncc.Enabled = false;
            btnLuu_ncc.Enabled = false;
            btnHuy_ncc.Enabled = false;
            LoadDataGridView_NCC();
            //Tab hàng hóa
            LoadDataGridView_HH();
            LoadDataGridView_HD();
            //setcombobox cho mã nhà cc ở tab hàng hóa
            string sql;
            sql = "SELECT * from nhacungcap";
            Functions.FillCombo(sql, cboManhacc_hh, "Manhacc", "Tennhacc");
            cboManhacc_hh.SelectedIndex = -1;
            //tab hóa đơn
            btnThem_hd.Enabled = true;
            btnLuu_hd.Enabled = false;
            btnXoa_hd.Enabled = false;
            btnIn_hd.Enabled = false;
            txtMahoadon_hd.ReadOnly = true;
            txtTennhanvien_hd.ReadOnly = true;
           
            //txtDiachi_hd.ReadOnly = true;
            //txtSDT_hd.ReadOnly = true;
            txtTenhang_hd.ReadOnly = true;
            txtDongia_hd.ReadOnly = true;
            txtThanhtien_hd.ReadOnly = true;
            txtTongTien_hd.ReadOnly = true;
            txtGiamgia_hd.Text = "0";
            txtTongTien_hd.Text = "0";
            
            Functions.FillCombo("SELECT Manv, Tennv FROM Nhanvien", cboManhanvien_hd, "Manv", "Tennv");
            cboManhanvien_hd.SelectedIndex = -1;
            Functions.FillCombo("SELECT Mahh, Tenhh FROM hanghoa", cboMahanghoa_hd, "Mahh", "Tenhh");
            cboMahanghoa_hd.SelectedIndex = -1;
            //Hiển thị thông tin của một hóa đơn được gọi từ form tìm kiếm
            if (txtMahoadon_hd.Text != "")
            {
                LoadInfoHoadon();
                btnXoa_hd.Enabled = true;
                btnIn_hd.Enabled = true;
            }
            //ytab nhân viên
            
        }
        //tải thông tin hóa đơn
        private void LoadInfoHoadon()
        {
            string str;
            str = "SELECT Ngayban FROM hoadon_ban WHERE MaHD_Ban = N'" + txtMahoadon_hd.Text + "'";
            txtNgayban_hd.Text = Functions.ConvertDateTime(Functions.GetFieldValues(str));
            str = "SELECT manv FROM hoadon_ban WHERE MaHD_Ban = N'" + txtMahoadon_hd.Text + "'";
            cboManhanvien_hd.Text = Functions.GetFieldValues(str);
            //str = "SELECT Makhach FROM hoado WHERE MaHDBan = N'" + txtMahoadon_hd.Text + "'";
           // cboMakhach.Text = Functions.GetFieldValues(str);
            str = "SELECT thanhtien FROM hoadon_ban WHERE MaHD_Ban = N'" + txtMahoadon_hd.Text + "'";
            txtTongTien_hd.Text = Functions.GetFieldValues(str);

            lblBangchu.Text =  Functions.NumberToTextVN(Convert.ToDouble(txtTongTien_hd.Text));
        }

        //reset textbox
        private void ResetValue()
        {
            //hàng hóa
            txtMahang_hh.Text = "";
            txtTenhang_hh.Text = "";
            txtDonvitinh_hh.Text = "";
            
            txtGianhap_hh.Text = "";
            txtGiaban_hh.Text = "";
            txtGhichu_hh.Text = "";
            txtSoluong_hh.Text = "";
           
        }
        //reset textbox hóa đơn
        private void ResetValues_HD()
        {
            txtMahoadon_hd.Text = "";
            txtNgayban_hd.Text = DateTime.Now.ToShortDateString();
            cboManhanvien_hd.Text = "";
            
            txtTongTien_hd.Text = "0";
            lblBangchu.Text = " ";
            cboMahanghoa_hd.Text = "";
            txtSoluong_hd.Text = "";
            txtGiamgia_hd.Text = "0";
            txtThanhtien_hd.Text = "0";
        }
        //reset nhan vien
        private void ResetValues_NV()
        {
            txtManhanvien_nv.Text = "";
            txtTennhanvien_nv.Text = "";
            chkGioitinh_nv.Checked = false;
            txtDiachi_nv.Text = "";
            txtNgaysinh_nv.Text = "";
            txtSDT_nv.Text = "";
        }
        private void ResetValues_NCC()
        {
            txtMaNCC_ncc.Text = "";
            txtTenNCC_ncc.Text = "";
            txtDiachi_ncc.Text = "";
            txtSDT_ncc.Text = "";
        }
        //cái này là reset của hàng hóa ở hóa đơn
        private void ResetValuesHang()
        {
            cboMahanghoa_hd.Text = "";
            txtSoluong_hd.Text = "";
            txtGiamgia_hd.Text = "0";
            txtThanhtien_hd.Text = "0";
        }

        private int codeno;
        //Xu ly button cho tab hang hoa
        private void btnThem_hh_Click(object sender, EventArgs e)
        {
            ResetValue();
            //txtMahang_hh.Enabled = false;
            btnHuy_hh.Enabled = true;
            btnLuu_hh.Enabled = true;
            //btnThem_hh.Enabled = true;
            btnThem_hh.Enabled = false;
            //txtMahang_hh.Enabled = false; //cho phép nhập mới
            //txtMahang_hh.Focus();
            string sql;
        
            sql = "Select Max(mahh) From hanghoa";
            codeno = Convert.ToInt32(Functions.GetFieldValues(sql));
            //MessageBox.Show("Bạn phải nhập đầy đủ thông tin" + codeno);
            codeno += 1;
            txtMahang_hh.Text = codeno.ToString();
            txtMahang_hh.Enabled = false;
            
        }

        private void btnLuu_hh_Click(object sender, EventArgs e)
        {
            string sql; //Lưu lệnh sql
            if (txtMahang_hh.Text.Trim().Length == 0 || cboManhacc_hh.Text.Trim() == "" ||  
                txtTenhang_hh.Text.Trim().Length == 0 || txtSoluong_hh.Text.Trim().Length == 0 ||
                txtGiaban_hh.Text.Trim().Length == 0 || txtGianhap_hh.Text.Trim().Length == 0
                || txtSoluong_hh.Text.Trim().Length == 0 || txtDonvitinh_hh.Text.Trim().Length == 0
                ) //Nếu chưa nhập  đủ
            {
                MessageBox.Show("Bạn phải nhập đầy đủ thông tin", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                //txtMachatlieu.Focus();
                return;
            }
            
            sql = "Select MaHH From hanghoa where MaHH=N'" + txtMahang_hh.Text.Trim() + "'";
            if (Control.Functions.CheckKey(sql))
            {
                MessageBox.Show("Mã hàng này đã có, bạn phải nhập mã khác", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtMahang_hh.Focus();
                return;
            }
            //if (txtGhichu_hh.Text == "")
            //{
                //sql = "INSERT INTO hanghoa VALUES(N'" +
                //txtMahang_hh.Text + "',N'" + txtTenhang_hh.Text + "',N'" + txtGiaban_hh.Text + "',N'" + txtDonvitinh_hh.Text + "',N'"
                //+ cboManhacc_hh.SelectedValue.ToString() + "',N'" + txtSoluong_hh.Text + "',N'" + txtGianhap_hh.Text + "',N'" + "')";
            //}
            //else {
                sql = "INSERT INTO hanghoa VALUES(N'" +
                txtMahang_hh.Text + "',N'" + txtTenhang_hh.Text + "'," + Int32.Parse(txtGiaban_hh.Text) + ",N'" + txtDonvitinh_hh.Text + "',N'"
                + cboManhacc_hh.SelectedValue.ToString() + "'," + Int32.Parse(txtSoluong_hh.Text) + "," + Int32.Parse(txtGianhap_hh.Text) + ",N'" + txtGhichu_hh.Text + "')";
            // }
                Control.Functions.RunSQL(sql); //Thực hiện câu lệnh sql
            LoadDataGridView_HH(); //Nạp lại DataGridView
            ResetValue();
            btnXoa_hh.Enabled = true;
            btnThem_hh.Enabled = true;
            btnSua_hh.Enabled = true;
            btnHuy_hh.Enabled = false;
            btnLuu_hh.Enabled = false;
            txtMahang_hh.Enabled = false;
        }



        //data grid view Hàng hóa click
        private void dataGridView_hh_Click(object sender, DataGridViewCellEventArgs e)
        {
            if (btnThem_hh.Enabled == false)
            {
                MessageBox.Show("Đang ở chế độ thêm mới!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtMahang_hh.Focus();
                return;
            }
            if (tblHH.Rows.Count == 0) //Nếu không có dữ liệu
            {
                MessageBox.Show("Không có dữ liệu!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            txtMahang_hh.Text = dataGridView_hh.CurrentRow.Cells["Mahh"].Value.ToString();
            txtTenhang_hh.Text = dataGridView_hh.CurrentRow.Cells["Tenhh"].Value.ToString();
            txtSoluong_hh.Text = dataGridView_hh.CurrentRow.Cells["Soluong"].Value.ToString();
            txtGiaban_hh.Text = dataGridView_hh.CurrentRow.Cells["Giaban"].Value.ToString();
            txtGianhap_hh.Text = dataGridView_hh.CurrentRow.Cells["Gianhap"].Value.ToString();
            txtDonvitinh_hh.Text = dataGridView_hh.CurrentRow.Cells["Donvitinh"].Value.ToString();
            cboManhacc_hh.Text = dataGridView_hh.CurrentRow.Cells["Manhacc"].Value.ToString();
            if (dataGridView_hh.CurrentRow.Cells["Ghichu"].Value != "")
            {
                txtGhichu_hh.Text = dataGridView_hh.CurrentRow.Cells["Ghichu"].Value.ToString();
            }
            btnSua_hh.Enabled = true;
            btnXoa_hh.Enabled = true;
            btnHuy_hh.Enabled = true;
        }

        private void btnSua_hh_Click(object sender, EventArgs e)
        {
            txtMahang_hh.Enabled = false;
            string sql;
            if (tblHH.Rows.Count == 0)
            {
                MessageBox.Show("Không còn dữ liệu", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            if (txtMahang_hh.Text == "")
            {
                MessageBox.Show("Bạn phải chọn bản ghi cần sửa", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            if (txtMahang_hh.Text.Trim().Length == 0 ||
                txtTenhang_hh.Text.Trim().Length == 0 || txtSoluong_hh.Text.Trim().Length == 0 ||
                txtGiaban_hh.Text.Trim().Length == 0 || txtGianhap_hh.Text.Trim().Length == 0
                || txtSoluong_hh.Text.Trim().Length == 0 || txtDonvitinh_hh.Text.Trim().Length == 0)
            {
                MessageBox.Show("Vui lòng nhập đầy đủ thông tin", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            sql = "UPDATE hanghoa SET Tenhh=N'" + txtTenhang_hh.Text.Trim().ToString() + "',soluong=N'" +
                txtSoluong_hh.Text.Trim().ToString() + "',Giaban=N'" + txtGiaban_hh.Text.Trim().ToString() + "', gianhap=N'" +
                txtGianhap_hh.Text.Trim().ToString() + "',Donvitinh=N'" + txtDonvitinh_hh.Text.Trim().ToString() + "',manhacc=N'" +
                cboManhacc_hh.Text.Trim().ToString() + "',Ghichu=N'" + txtGhichu_hh.Text.Trim().ToString() +
                "' WHERE Mahh=N'" + txtMahang_hh.Text + "'";
            Control.Functions.RunSQL(sql);
            LoadDataGridView_HH();
            MessageBox.Show("Cập nhật thành công", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            ResetValue();
            btnHuy_hh.Enabled = false;
        }

        private void btnHuy_hh_Click(object sender, EventArgs e)
        {
            ResetValue();
            btnThem_hh.Enabled = true;
            btnSua_hh.Enabled = false;
            btnXoa_hh.Enabled = false;
            btnLuu_hh.Enabled = false;
        }

        private void btnXoa_hh_Click(object sender, EventArgs e)
        {
            string sql;
            if (tblHH.Rows.Count == 0)
            {
                MessageBox.Show("Không có dữ liệu", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            if (txtMahang_hh.Text.Trim() == "")
            {
                MessageBox.Show("Bạn chưa chọn hàng hóa nào", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            if (MessageBox.Show("Bạn có muốn xoá hàng hóa này không?", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                sql = "DELETE hanghoa WHERE Mahh=N'" + txtMahang_hh.Text + "'";
                Control.Functions.RunSqlDel(sql);
                LoadDataGridView_HH();
                ResetValue();
                MessageBox.Show("Xóa thành công", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                btnThem_hh.Enabled = true;
                btnSua_hh.Enabled = false;
                btnXoa_hh.Enabled = false;
                btnLuu_hh.Enabled = false;
                btnHuy_hh.Enabled = false;
            }
        }

        
        private void cboManhacc_hh_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnThem_hd_Click(object sender, EventArgs e)
        {
            btnXoa_hd.Enabled = false;
            btnLuu_hd.Enabled = true;
            btnIn_hd.Enabled = false;
            btnThem_hd.Enabled = false;
            ResetValues_HD();
            txtMahoadon_hd.Text = Functions.CreateKey("HDB");
            LoadDataGridView_HD();
        }

        private void btnThem_nv_Click(object sender, EventArgs e)
        {
            int manv;
            ResetValues_NV();
            //txtMahang_hh.Enabled = false;
            btnHuy_nv.Enabled = true;
            btnLuu_nv.Enabled = true;
            //btnThem_hh.Enabled = true;
            btnThem_nv.Enabled = false;
            //txtMahang_hh.Enabled = false; //cho phép nhập mới
            //txtMahang_hh.Focus();
            string sql;

            sql = "Select Max(manv) From nhanvien";
            manv = Convert.ToInt32(Functions.GetFieldValues(sql));
            //MessageBox.Show("Bạn phải nhập đầy đủ thông tin" + codeno);
            manv += 1;
            txtManhanvien_nv.Text = manv.ToString();
            txtManhanvien_nv.Enabled = false;
        }

        private void btnLuu_nv_Click(object sender, EventArgs e)
        {
            string sql, gt;
            if (txtManhanvien_nv.Text.Trim().Length == 0)
            {
                MessageBox.Show("Bạn phải nhập mã nhân viên", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtManhanvien_nv.Focus();
                return;
            }
            if (txtTennhanvien_nv.Text.Trim().Length == 0)
            {
                MessageBox.Show("Bạn phải nhập tên nhân viên", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtTennhanvien_nv.Focus();
                return;
            }
            if (txtDiachi_nv.Text.Trim().Length == 0)
            {
                MessageBox.Show("Bạn phải nhập địa chỉ", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtDiachi_nv.Focus();
                return;
            }
            if (txtSDT_nv.Text == "")
            {
                MessageBox.Show("Bạn phải nhập điện thoại", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtSDT_nv.Focus();
                return;
            }
            if (txtNgaysinh_nv.Text == "  /  /")
            {
                MessageBox.Show("Bạn phải nhập ngày sinh", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtNgaysinh_nv.Focus();
                return;
            }
            if (!Functions.IsDate(txtNgaysinh_nv.Text))
            {
                MessageBox.Show("Bạn phải nhập lại ngày sinh", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                // mskNgaysinh.Text = "";
                txtNgaysinh_nv.Focus();
                return;
            }
            if (chkGioitinh_nv.Checked == true)
                gt = "Nam";
            else
                gt = "Nữ";
            sql = "SELECT Manv FROM Nhanvien WHERE Manv=N'" + txtManhanvien_nv.Text.Trim() + "'";
            if (Functions.CheckKey(sql))
            {
                MessageBox.Show("Mã nhân viên này đã có, bạn phải nhập mã khác", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtManhanvien_nv.Focus();
                txtManhanvien_nv.Text = "";
                return;
            }
            sql = "INSERT INTO Nhanvien(Manv,Tennv,Gioitinh, Ngaysinh, SDT, Diachi) VALUES (N'" + txtManhanvien_nv.Text.Trim() + "',N'" + txtTennhanvien_nv.Text.Trim() + "',N'" + gt + "',N'" + Functions.ConvertDateTime(txtNgaysinh_nv.Text) + "','" + txtSDT_nv.Text + "',N'" + txtDiachi_nv.Text.Trim() + "')";
            Functions.RunSQL(sql);
            LoadDataGridView_NV();
            ResetValues_NV();
            btnXoa_nv.Enabled = true;
            btnThem_nv.Enabled = true;
            btnSua_nv.Enabled = true;
            btnHuy_nv.Enabled = false;
            btnLuu_nv.Enabled = false;
            txtManhanvien_nv.Enabled = false;
        }

        private void dataGridView_nv_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (btnThem_nv.Enabled == false)
            {
                MessageBox.Show("Đang ở chế độ thêm mới!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtManhanvien_nv.Focus();
                return;
            }
            if (tblNV.Rows.Count == 0)
            {
                MessageBox.Show("Không có dữ liệu!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            txtManhanvien_nv.Text = dataGridView_nv.CurrentRow.Cells["Manv"].Value.ToString();
            txtTennhanvien_nv.Text = dataGridView_nv.CurrentRow.Cells["Tennv"].Value.ToString();
            if (dataGridView_nv.CurrentRow.Cells["Gioitinh"].Value.ToString() == "Nam") chkGioitinh_nv.Checked = true;
            else chkGioitinh_nv.Checked = false;
            txtDiachi_nv.Text = dataGridView_nv.CurrentRow.Cells["Diachi"].Value.ToString();
            txtSDT_nv.Text = dataGridView_nv.CurrentRow.Cells["SDT"].Value.ToString();
            txtNgaysinh_nv.Text = dataGridView_nv.CurrentRow.Cells["Ngaysinh"].Value.ToString();
            btnSua_nv.Enabled = true;
            btnXoa_nv.Enabled = true;
        }

        private void btnSua_nv_Click(object sender, EventArgs e)
        {
            string sql, gt;
            if (tblNV.Rows.Count == 0)
            {
                MessageBox.Show("Không còn dữ liệu!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            if (txtManhanvien_nv.Text == "")
            {
                MessageBox.Show("Bạn chưa chọn bản ghi nào", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            if (txtTennhanvien_nv.Text.Trim().Length == 0)
            {
                MessageBox.Show("Bạn phải nhập tên nhân viên", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtTennhanvien_nv.Focus();
                return;
            }
            if (txtDiachi_nv.Text.Trim().Length == 0)
            {
                MessageBox.Show("Bạn phải nhập địa chỉ", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtDiachi_nv.Focus();
                return;
            }
            if (txtSDT_nv.Text == "(   )     -")
            {
                MessageBox.Show("Bạn phải nhập điện thoại", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtSDT_nv.Focus();
                return;
            }
            if (txtNgaysinh_nv.Text == "  /  /")
            {
                MessageBox.Show("Bạn phải nhập ngày sinh", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtNgaysinh_nv.Focus();
                return;
            }
            if (!Functions.IsDate(txtNgaysinh_nv.Text))
            {
                MessageBox.Show("Bạn phải nhập lại ngày sinh", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtNgaysinh_nv.Text = "";
                txtNgaysinh_nv.Focus();
                return;
            }
            if (chkGioitinh_nv.Checked == true)
                gt = "Nam";
            else
                gt = "Nữ";
            sql = "UPDATE Nhanvien SET  Tennv=N'" + txtTennhanvien_nv.Text.Trim().ToString() +
                    "',Diachi=N'" + txtDiachi_nv.Text.Trim().ToString() +
                    "',SDT='" + txtSDT_nv.Text.ToString() + "',Gioitinh=N'" + gt +
                    "',Ngaysinh='" + Functions.ConvertDateTime(txtNgaysinh_nv.Text) +
                    "' WHERE Manv=N'" + txtManhanvien_nv.Text + "'";
            Functions.RunSQL(sql);
            LoadDataGridView_NV();
            ResetValues_NV();
            btnHuy_nv.Enabled = false;
        }

        private void btnHuy_nv_Click(object sender, EventArgs e)
        {
            ResetValues_NV();
            btnHuy_nv.Enabled = false;
            btnThem_nv.Enabled = true;
            btnXoa_nv.Enabled = true;
            btnSua_nv.Enabled = true;
            btnLuu_nv.Enabled = false;
            txtManhanvien_nv.Enabled = false;
        }

        private void btnXoa_nv_Click(object sender, EventArgs e)
        {
            string sql;
            if (tblNV.Rows.Count == 0)
            {
                MessageBox.Show("Không còn dữ liệu!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            if (txtManhanvien_nv.Text == "")
            {
                MessageBox.Show("Bạn chưa chọn nhân viên nào", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            if (MessageBox.Show("Bạn có muốn xóa nhân viên này không?", "Thông báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) == DialogResult.OK)
            {
                sql = "DELETE Nhanvien WHERE Manv=N'" + txtManhanvien_nv.Text + "'";
                Functions.RunSqlDel(sql);
                LoadDataGridView_NV();
                ResetValues_NV();
            }
        }

        private void btnLuu_hd_Click(object sender, EventArgs e)
        {
            string sql;
            double sl, SLcon, tong, Tongmoi;
            sql = "SELECT MaHD_Ban FROM hoadon_ban WHERE MaHD_Ban=N'" + txtMahoadon_hd.Text + "'";
            if (!Functions.CheckKey(sql))
            {
                // Mã hóa đơn chưa có, tiến hành lưu các thông tin chung
                // Mã HDBan được sinh tự động do đó không có trường hợp trùng khóa
                if (txtNgayban_hd.Text.Length == 0)
                {
                    MessageBox.Show("Bạn phải nhập ngày bán", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtNgayban_hd.Focus();
                    return;
                }
                if (cboManhanvien_hd.Text.Length == 0)
                {
                    MessageBox.Show("Bạn phải nhập nhân viên", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    cboManhanvien_hd.Focus();
                    return;
                }
                /*if (cboMakhach.Text.Length == 0)
                {
                    MessageBox.Show("Bạn phải nhập khách hàng", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    cboMakhach.Focus();
                    return;
                }*/
                sql = "INSERT INTO Hoadon_Ban(MaHD_Ban,  Manv, Ngayban, Thanhtien) VALUES (N'" + txtMahoadon_hd.Text.Trim() + "',N'" + cboManhanvien_hd.SelectedValue + "','" +
                        txtNgayban_hd.Text.Trim() + "'," + txtTongTien_hd.Text + ")";
                Functions.RunSQL(sql);
            }
            // Lưu thông tin của các mặt hàng
            if (cboMahanghoa_hd.Text.Trim().Length == 0)
            {
                MessageBox.Show("Bạn phải nhập mã hàng", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                cboMahanghoa_hd.Focus();
                return;
            }
            if ((txtSoluong_hd.Text.Trim().Length == 0) || (txtSoluong_hd.Text == "0"))
            {
                MessageBox.Show("Bạn phải nhập số lượng", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtSoluong_hd.Text = "";
                txtSoluong_hd.Focus();
                return;
            }
            if (txtGiamgia_hd.Text.Trim().Length == 0)
            {
                MessageBox.Show("Bạn phải nhập giảm giá", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtGiamgia_hd.Focus();
                return;
            }
            sql = "SELECT Mahh FROM Chitiethoadon_Ban WHERE Mahh=N'" + cboMahanghoa_hd.SelectedValue + "' AND MaHD_Ban = N'" + txtMahoadon_hd.Text.Trim() + "'";
            if (Functions.CheckKey(sql))
            {
                MessageBox.Show("Mã hàng này đã có, bạn phải nhập mã khác", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                ResetValuesHang();
                cboMahanghoa_hd.Focus();
                return;
            }
            // Kiểm tra xem số lượng hàng trong kho còn đủ để cung cấp không?
            sl = Convert.ToDouble(Functions.GetFieldValues("SELECT Soluong FROM hanghoa WHERE Mahh = N'" + cboMahanghoa_hd.SelectedValue + "'"));
            if (Convert.ToDouble(txtSoluong_hd.Text) > sl)
            {
                MessageBox.Show("Số lượng mặt hàng này chỉ còn " + sl, "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtSoluong_hd.Text = "";
                txtSoluong_hd.Focus();
                return;
            }
            sql = "INSERT INTO Chitiethoadon_Ban(MaHD_Ban, Mahh, Soluong, Dongia, Giamgia, Thanhtien) VALUES(N'" + txtMahoadon_hd.Text.Trim() + "',N'" + cboMahanghoa_hd.SelectedValue + "'," + txtSoluong_hd.Text + "," + txtDongia_hd.Text + "," + txtGiamgia_hd.Text + "," + txtThanhtien_hd.Text + ")";
            Functions.RunSQL(sql);
            LoadDataGridView_HD();
            // Cập nhật lại số lượng của mặt hàng vào bảng tblHang
            SLcon = sl - Convert.ToDouble(txtSoluong_hd.Text);
            sql = "UPDATE hanghoa SET Soluong =" + SLcon + " WHERE Mahh= N'" + cboMahanghoa_hd.SelectedValue + "'";
            Functions.RunSQL(sql);
            // Cập nhật lại tổng tiền cho hóa đơn bán
            tong = Convert.ToDouble(Functions.GetFieldValues_so("SELECT thanhtien FROM hoadon_ban WHERE MaHD_Ban = N'" + txtMahoadon_hd.Text + "'"));
            Tongmoi = tong + Convert.ToDouble(txtThanhtien_hd.Text);
            sql = "UPDATE hoadon_ban SET Thanhtien =" + Tongmoi + " WHERE MaHD_Ban = N'" + txtMahoadon_hd.Text + "'";
            Functions.RunSQL(sql);
            txtTongTien_hd.Text = Tongmoi.ToString();
            lblBangchu.Text =  Functions.NumberToTextVN(Tongmoi);
            ResetValuesHang();
            btnXoa_hd.Enabled = true;
            btnThem_hd.Enabled = true;
            btnIn_hd.Enabled = true;
            LoadDataGridView_HD();
        }
       
        private void dataGridView_hd_DoubleClick(object sender, EventArgs e)
        {
            string mahangxoa, sql;
            Double thanhtienxoa, soluongxoa, sl, slcon, tong, tongmoi;
            if (tblCTHD.Rows.Count == 0)
            {
                MessageBox.Show("Không có dữ liệu!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            if ((MessageBox.Show("Bạn có chắc chắn muốn xóa không?", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes))
            {
                //Xóa hàng và cập nhật lại số lượng hàng 
                mahangxoa = dataGridView_hd.CurrentRow.Cells["Mahh"].Value.ToString();
                soluongxoa = Convert.ToDouble(dataGridView_hd.CurrentRow.Cells["Soluong"].Value.ToString());
                thanhtienxoa = Convert.ToDouble(dataGridView_hd.CurrentRow.Cells["Thanhtien"].Value.ToString());
                sql = "DELETE ChitietHoadon_Ban WHERE MaHD_Ban=N'" + txtMahoadon_hd.Text + "' AND Mahh = N'" + mahangxoa + "'";
                Functions.RunSQL(sql);
                // Cập nhật lại số lượng cho các mặt hàng
                sl = Convert.ToDouble(Functions.GetFieldValues("SELECT Soluong FROM hanghoa WHERE Mahh = N'" + mahangxoa + "'"));
                slcon = sl + soluongxoa;
                sql = "UPDATE hanghoa SET Soluong =" + slcon + " WHERE Mahh= N'" + mahangxoa + "'";
                Functions.RunSQL(sql);
                // Cập nhật lại tổng tiền cho hóa đơn bán
                tong = Convert.ToDouble(Functions.GetFieldValues("SELECT Thanhtien FROM HOadon_Ban WHERE MaHD_Ban = N'" + txtMahoadon_hd.Text + "'"));
                tongmoi = tong - thanhtienxoa;
                sql = "UPDATE hoadon_ban SET Thanhtien =" + tongmoi + " WHERE MaHD_Ban = N'" + txtMahoadon_hd.Text + "'";
                Functions.RunSQL(sql);
                txtTongTien_hd.Text = tongmoi.ToString();
                lblBangchu.Text =  Functions.NumberToTextVN(tongmoi);
                LoadDataGridView_HD();
            }
        }

        private void btnXoa_hd_Click(object sender, EventArgs e)
        {
            double sl, slcon, slxoa;
            if (MessageBox.Show("Bạn có chắc chắn muốn xóa hóa đơn này không?", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                string sql = "SELECT Mahh,Soluong FROM ChitietHoadon_Ban WHERE MaHD_Ban = N'" + txtMahoadon_hd.Text + "'";
                DataTable tblHang = Functions.GetDataToTable(sql);
                for (int hang = 0; hang <= tblHang.Rows.Count - 1; hang++)
                {
                    // Cập nhật lại số lượng cho các mặt hàng
                    sl = Convert.ToDouble(Functions.GetFieldValues("SELECT Soluong FROM hanghoa WHERE Mahh = N'" + tblHang.Rows[hang][0].ToString() + "'"));
                    slxoa = Convert.ToDouble(tblHang.Rows[hang][1].ToString());
                    slcon = sl + slxoa;
                    sql = "UPDATE hanghoa SET Soluong =" + slcon + " WHERE Mahh= N'" + tblHang.Rows[hang][0].ToString() + "'";
                    Functions.RunSQL(sql);
                }

                //Xóa chi tiết hóa đơn
                sql = "DELETE chitiethoadon_ban WHERE MaHD_Ban=N'" + txtMahoadon_hd.Text + "'";
                Functions.RunSqlDel(sql);

                //Xóa hóa đơn
                sql = "DELETE hoadon_ban WHERE MaHD_Ban=N'" + txtMahoadon_hd.Text + "'";
                Functions.RunSqlDel(sql);
                ResetValues_HD();
                LoadDataGridView_HD();
                btnXoa_hd.Enabled = false;
                btnIn_hd.Enabled = false;
            }
        }

        private void cboManhanvien_hd_TextChanged(object sender, EventArgs e)
        {
            string str;
            if (cboManhanvien_hd.Text == "")
                txtTennhanvien_hd.Text = "";
            // Khi chọn Mã nhân viên thì tên nhân viên tự động hiện ra
            str = "Select Tennv from Nhanvien where Manv =N'" + cboManhanvien_hd.SelectedValue + "'";
            txtTennhanvien_hd.Text = Functions.GetFieldValues(str);
        }

        private void cboMahanghoa_hd_TextChanged(object sender, EventArgs e)
        {
            string str;
            if (cboMahanghoa_hd.Text == "")
            {
                txtTenhang_hd.Text = "";
                txtDongia_hd.Text = "";
            }
            // Khi chọn mã hàng thì các thông tin về hàng hiện ra
            str = "SELECT Tenhh FROM Hanghoa WHERE Mahh =N'" + cboMahanghoa_hd.SelectedValue + "'";
            txtTenhang_hd.Text = Functions.GetFieldValues(str);
            str = "SELECT giaban FROM Hanghoa WHERE Mahh =N'" + cboMahanghoa_hd.SelectedValue + "'";
            txtDongia_hd.Text = Functions.GetFieldValues(str);
        }

        private void txtSoluong_hd_TextChanged(object sender, EventArgs e)
        {
            //Khi thay đổi số lượng thì thực hiện tính lại thành tiền
            double tt, sl, dg, gg;
            if (txtSoluong_hd.Text == "")
                sl = 0;
            else
                sl = Convert.ToDouble(txtSoluong_hd.Text);
            if (txtGiamgia_hd.Text == "")
                gg = 0;
            else
                gg = Convert.ToDouble(txtGiamgia_hd.Text);
            if (txtDongia_hd.Text == "")
                dg = 0;
            else
                dg = Convert.ToDouble(txtDongia_hd.Text);
            tt = sl * dg - sl * dg * gg / 100;
            txtThanhtien_hd.Text = tt.ToString();
        }

        private void txtGiamgia_hd_TextChanged(object sender, EventArgs e)
        {
            //Khi thay đổi giảm giá thì tính lại thành tiền
            double tt, sl, dg, gg;
            if (txtSoluong_hd.Text == "")
                sl = 0;
            else
                sl = Convert.ToDouble(txtSoluong_hd.Text);
            if (txtGiamgia_hd.Text == "")
                gg = 0;
            else
                gg = Convert.ToDouble(txtGiamgia_hd.Text);
            if (txtDongia_hd.Text == "")
                dg = 0;
            else
                dg = Convert.ToDouble(txtDongia_hd.Text);
            tt = sl * dg - sl * dg * gg / 100;
            txtThanhtien_hd.Text = tt.ToString();
        }

        private void dataGridView_hd_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            string mahangxoa, sql;
            Double thanhtienxoa, soluongxoa, sl, slcon, tong, tongmoi;
           
            if ((MessageBox.Show("Bạn có chắc chắn muốn xóa không?", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes))
            {
                //Xóa hàng và cập nhật lại số lượng hàng 
                mahangxoa = dataGridView_hd.CurrentRow.Cells["Mahh"].Value.ToString();
                soluongxoa = Convert.ToDouble(dataGridView_hd.CurrentRow.Cells["Soluong"].Value.ToString());
                thanhtienxoa = Convert.ToDouble(dataGridView_hd.CurrentRow.Cells["Thanhtien"].Value.ToString());
                sql = "DELETE ChitietHoadon_Ban WHERE MaHD_Ban=N'" + txtMahoadon_hd.Text + "' AND Mahh = N'" + mahangxoa + "'";
                Functions.RunSQL(sql);
                // Cập nhật lại số lượng cho các mặt hàng
                sl = Convert.ToDouble(Functions.GetFieldValues("SELECT Soluong FROM hanghoa WHERE Mahh = N'" + mahangxoa + "'"));
                slcon = sl + soluongxoa;
                sql = "UPDATE hanghoa SET Soluong =" + slcon + " WHERE Mahh= N'" + mahangxoa + "'";
                Functions.RunSQL(sql);
                // Cập nhật lại tổng tiền cho hóa đơn bán
                tong = Convert.ToDouble(Functions.GetFieldValues("SELECT Thanhtien FROM HOadon_Ban WHERE MaHD_Ban = N'" + txtMahoadon_hd.Text + "'"));
                tongmoi = tong - thanhtienxoa;
                sql = "UPDATE hoadon_ban SET Thanhtien =" + tongmoi + " WHERE MaHD_Ban = N'" + txtMahoadon_hd.Text + "'";
                Functions.RunSQL(sql);
                txtTongTien_hd.Text = tongmoi.ToString();
                lblBangchu.Text =  Functions.NumberToTextVN(tongmoi);
                LoadDataGridView_HD();
            }
        }

        private void btnIn_hd_Click(object sender, EventArgs e)
        {
            // Khởi động chương trình Excel
            COMExcel.Application exApp = new COMExcel.Application();
            COMExcel.Workbook exBook; //Trong 1 chương trình Excel có nhiều Workbook
            COMExcel.Worksheet exSheet; //Trong 1 Workbook có nhiều Worksheet
            COMExcel.Range exRange;
            string sql;
            int hang = 0, cot = 0;
            DataTable tblThongtinHD, tblThongtinHang;
            exBook = exApp.Workbooks.Add(COMExcel.XlWBATemplate.xlWBATWorksheet);
            exSheet = (COMExcel.Worksheet)exBook.Worksheets[1];

            exSheet.Activate();
            exSheet.Name = "Hóa đơn";
            // Định dạng chung
            COMExcel.Range a1_z300 = (COMExcel.Range)exSheet.get_Range("A1", "Z300"); // khối a1-z300
            
            a1_z300.Font.Name = "Times new roman"; //Font chữ
            COMExcel.Range a1_b3 = (COMExcel.Range)exSheet.get_Range("A1", "B3");
            a1_b3.Font.Size = 10;
            a1_b3.Font.Bold = true;
            a1_b3.Font.ColorIndex = 5; //Màu xanh da trời
            COMExcel.Range a1 = (COMExcel.Range)exSheet.Cells[1,1]; //ô a1
            a1.ColumnWidth = 7;
            COMExcel.Range b1 = (COMExcel.Range)exSheet.Cells[2, 2]; //ô b1
            b1.ColumnWidth = 15;
            COMExcel.Range a1_b1 = (COMExcel.Range)exSheet.get_Range("A1", "B1");
            a1_b1.MergeCells = true;
            a1_b1.HorizontalAlignment = COMExcel.XlHAlign.xlHAlignCenter;
            a1_b1.Value2 = "Nhat Quang's store";
            COMExcel.Range a2_b2 = (COMExcel.Range)exSheet.get_Range("A2", "B2");
            a2_b2.MergeCells = true;
            a2_b2.HorizontalAlignment = COMExcel.XlHAlign.xlHAlignCenter;
            a2_b2.Value2 = "Ninh Kiều - Cần Thơ";
            COMExcel.Range a3_b3 = (COMExcel.Range)exSheet.get_Range("A3", "B3");
            a3_b3.MergeCells = true;
            a3_b3.HorizontalAlignment = COMExcel.XlHAlign.xlHAlignCenter;
            a3_b3.Value2 = "Điện thoại: (84)0966310858";
            COMExcel.Range c2_e2 = (COMExcel.Range)exSheet.get_Range("C2", "E2");
            c2_e2.Font.Size = 16;
            c2_e2.Font.Bold = true;
            c2_e2.Font.ColorIndex = 3; //Màu đỏ
            c2_e2.MergeCells = true;
            c2_e2.HorizontalAlignment = COMExcel.XlHAlign.xlHAlignCenter;
            c2_e2.Value2 = "HÓA ĐƠN BÁN LẺ";
            // Biểu diễn thông tin chung của hóa đơn bán
            sql = "SELECT a.MaHD_Ban, a.Ngayban, a.Thanhtien, c.Tennv FROM hoadon_ban AS a, Nhanvien AS c WHERE a.MaHD_Ban = N'" + txtMahoadon_hd.Text + "' AND a.Manv = c.Manv";
            tblThongtinHD = Functions.GetDataToTable(sql);
            COMExcel.Range b6_c9 = (COMExcel.Range)exSheet.get_Range("B6", "C9");
            b6_c9.Font.Size = 12;
            COMExcel.Range b5 = (COMExcel.Range)exSheet.get_Range("B5", "B5");
            b5.Value2 = "Mã hóa đơn:";
            COMExcel.Range c5_e5 = (COMExcel.Range)exSheet.get_Range("C5", "E5");
            c5_e5.MergeCells = true;
            c5_e5.Value2 = tblThongtinHD.Rows[0][0].ToString();
           
            //Lấy thông tin các mặt hàng
            sql = "SELECT b.Tenhh, a.Soluong, b.giaban, a.giamgia, a.Thanhtien " +
                  "FROM chitiethoadon_ban AS a , hanghoa AS b WHERE a.MaHD_Ban = N'" +
                  txtMahoadon_hd.Text + "' AND a.Mahh = b.Mahh";
            tblThongtinHang = Functions.GetDataToTable(sql);
            //Tạo dòng tiêu đề bảng
            COMExcel.Range a7_f7 = (COMExcel.Range)exSheet.get_Range("A7", "F7");
            a7_f7.Font.Bold = true;
            a7_f7.HorizontalAlignment = COMExcel.XlHAlign.xlHAlignCenter;
            COMExcel.Range c7_f7 = (COMExcel.Range)exSheet.get_Range("C7", "F7");
            c7_f7.ColumnWidth = 12;
            COMExcel.Range a7 = (COMExcel.Range)exSheet.get_Range("A7", "A7");
            a7.Value2 = "STT";
            COMExcel.Range b7 = (COMExcel.Range)exSheet.get_Range("B7", "B7");
            b7.Value2 = "Tên Hàng";
            b7.ColumnWidth = 25;
            COMExcel.Range c11 = (COMExcel.Range)exSheet.get_Range("C7", "C7");
            c11.Value2 = "Số lượng";
            COMExcel.Range d11 = (COMExcel.Range)exSheet.get_Range("D7", "D7");
            d11.Value2 = "Đơn giá";
            COMExcel.Range e11 = (COMExcel.Range)exSheet.get_Range("E7", "E7");
            e11.Value2 = "Giảm giá (%)";
            COMExcel.Range f11 = (COMExcel.Range)exSheet.get_Range("F7", "F7");
            f11.Value2 = "Thành tiền";
            // lặp số lần tương ứng với số sản phẩm
            
            for (hang = 0; hang < tblThongtinHang.Rows.Count; hang++)
            {
                //int o = 2;
                //Điền số thứ tự
                exSheet.Cells[8 + hang, 1] = hang + 1;
                //lặp cột của sp, ( tên[0], sl[1], dg[2], gg[3], tt[4])
                
                for (cot = 0; cot < tblThongtinHang.Columns.Count; cot++)
                //Điền thông tin hàng từ cột thứ 2, dòng 12
                {   
                    // cột lần đầu tiên là cột tên hàng
                    // ô lần  đầu là ô thứ  B8 [8,2]
                    
                    exSheet.Cells[hang + 8, cot+2] = tblThongtinHang.Rows[hang][cot].ToString();
                    //exSheet.Cells[hang + 8, cot+2].HorizontalAlignment = COMExcel.XlHAlign.xlHAlignCenter;
                    //if (cot == 3) exSheet.Cells[cot + 2,hang + 12] = tblThongtinHang.Rows[hang][cot].ToString() + "%";
                    //o++;
                }
            }
            COMExcel.Range tt = (COMExcel.Range)exSheet.Cells[8 + hang + 2, 5];
            tt.Font.Bold = true;
            tt.Value2 = "Tổng tiền:";
            
           
            //tổng tiền value
            COMExcel.Range ttv = (COMExcel.Range)exSheet.Cells[hang + 10, 6];
            ttv.Font.Bold = true;
            ttv.Value2 = tblThongtinHD.Rows[0][2].ToString();
            //author: Nhat Quang
            //bằng chữ
            COMExcel.Range bc = (COMExcel.Range)exSheet.Cells[hang + 11, 4];
            //bc.MergeCells = true;
            bc.Font.Bold = true;
            bc.Font.Italic = true;
            bc.HorizontalAlignment = COMExcel.XlHAlign.xlHAlignRight;
            bc.Value2 = "Bằng chữ: ";
            //value của bằng chữ:
            COMExcel.Range bcv = (COMExcel.Range)exSheet.Cells[hang + 11, 5];
            bcv.Font.Bold = true;
            bcv.Value2 = Functions.NumberToTextVN(Convert.ToDouble(tblThongtinHD.Rows[0][2]));

            //Ngày tháng ở dưới
            DateTime d = Convert.ToDateTime(tblThongtinHD.Rows[0][1]);
            COMExcel.Range date = (COMExcel.Range)exSheet.Cells[hang + 13, 5];
            date.Font.Italic = true;
            date.Value2 = "Cần Thơ, ngày " + d.Day + " tháng "+d.Month+ " năm " + d.Year;
            date.MergeCells = true;
            date.HorizontalAlignment = COMExcel.XlHAlign.xlHAlignCenter;
            //nhân viên
            COMExcel.Range nv = (COMExcel.Range)exSheet.Cells[hang + 14, 5];
            nv.MergeCells = true;
            nv.Font.Italic = true;
            nv.HorizontalAlignment = COMExcel.XlHAlign.xlHAlignCenter;
            nv.Value2 = "Nhân viên bán hàng";
            //bỏ 3 hàng choo nv nó ký
            //Tên nhân viên từ csdl
            COMExcel.Range tennv = (COMExcel.Range)exSheet.Cells[hang + 18, 5];
            tennv.MergeCells = true;
            tennv.Font.Italic = true;
            tennv.HorizontalAlignment = COMExcel.XlHAlign.xlHAlignCenter;
            tennv.Value2 = tblThongtinHD.Rows[0][3];
            
            exApp.Visible = true;
        }

        /*private void btnTimkiem_hd_Click(object sender, EventArgs e)
        {
            //if (cboMahoadon_hd.Text == "")
            //{
                MessageBox.Show("Bạn phải chọn một mã hóa đơn để tìm", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                cboMahoadon_hd.Focus();
                return;
            }
            txtMahoadon_hd.Text = cboMahoadon_hd.Text;
            LoadInfoHoadon();
            LoadDataGridView_HD();
            btnXoa_hd.Enabled = true;
            btnLuu_hd.Enabled = true;
            btnIn_hd.Enabled = true;
            cboMahoadon_hd.SelectedIndex = -1;
        }*/

        private void cboMahoadon_hd_DropDown(object sender, EventArgs e)
        {
            //Functions.FillCombo("SELECT MaHD_Ban FROM hoadon_ban", cboMahoadon_hd, "MaHD_Ban", "MaHD_Ban");
            //cboMahoadon_hd.SelectedIndex = -1;
 
        }

        private void tabPage5_Click(object sender, EventArgs e)
        {

        }

        private void label43_Click(object sender, EventArgs e)
        {

        }

        private void cboMa_hh_DropDown(object sender, EventArgs e)
        {
            //Functions.FillCombo("SELECT mahh FROM hanghoa", cboMa_hh, "Mahh", "MaHh");
            //cboMa_hh.SelectedIndex = -1;
        }
        DataTable hang, nhanvien;
        private void btnTimkiem_hh_Click(object sender, EventArgs e)
        {
            if (txtTenhh_tk.Text == "")
            {
                MessageBox.Show("Bạn phải nhập tên hàng hàng để tìm", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtTenhh_tk.Focus();
                return;
            }
            ConnectToSQL.Connect();
            string sql = "SELECT * from hanghoa where tenhh Like N'%" + txtTenhh_tk.Text + "%'";
            hang = Functions.GetDataToTable(sql);
            dataGridView_hh.DataSource = hang;
        }

        private void cboMa_nv_DropDown(object sender, EventArgs e)
        {
            //Functions.FillCombo("SELECT manv FROM nhanvien", cboMa_nv, "Manv", "Manv");
            //cboMa_nv.SelectedIndex = -1;
        }

        private void btnTimkiem_nv_Click(object sender, EventArgs e)
        {
            if (txtTennv_tk.Text == "")
            {
                MessageBox.Show("Bạn phải chọn một mã hàng để tìm", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtTennv_tk.Focus();
                return;
            }
            ConnectToSQL.Connect();
            string sql = "SELECT * from nhanvien where tennv Like N'%" + txtTennv_tk.Text + "%'";
            nhanvien = Functions.GetDataToTable(sql);
            dataGridView_nv.DataSource = nhanvien;
        }

        private void btnThem_ncc_Click(object sender, EventArgs e)
        {
            int mancc;
            ResetValues_NCC();
            //txtMahang_hh.Enabled = false;
            btnHuy_ncc.Enabled = true;
            btnLuu_ncc.Enabled = true;
            //btnThem_hh.Enabled = true;
            btnThem_ncc.Enabled = false;
            //txtMahang_hh.Enabled = false; //cho phép nhập mới
            //txtMahang_hh.Focus();
            string sql;

            sql = "Select Max(manhacc) From nhacungcap";
            mancc = Convert.ToInt32(Functions.GetFieldValues(sql));
            //MessageBox.Show("Bạn phải nhập đầy đủ thông tin" + codeno);
            mancc += 1;
            txtMaNCC_ncc.Text = codeno.ToString();
            txtMaNCC_ncc.Enabled = false;
        }

        private void btnHuy_ncc_Click(object sender, EventArgs e)
        {
            ResetValues_NCC();
            btnHuy_ncc.Enabled = false;
            btnThem_ncc.Enabled = true;
            btnXoa_ncc.Enabled = true;
            btnSua_ncc.Enabled = true;
            btnLuu_ncc.Enabled = false;
            txtMaNCC_ncc.Enabled = false;
        }

        private void btnLuu_ncc_Click(object sender, EventArgs e)
        {
            string sql; //Lưu lệnh sql
            if (txtMaNCC_ncc.Text.Trim().Length == 0
                || txtTenNCC_ncc.Text.Trim().Length == 0
                || txtDiachi_ncc.Text.Trim().Length == 0
                || txtSDT_ncc.Text.Trim().Length == 0
                ) //Nếu chưa nhập  đủ
            {
                MessageBox.Show("Bạn phải nhập đầy đủ thông tin", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                //txtMachatlieu.Focus();
                return;
            }

            sql = "Select Manhacc From nhacungcap where Manhacc=N'" + txtMaNCC_ncc.Text.Trim() + "'";
            if (Control.Functions.CheckKey(sql))
            {
                MessageBox.Show("Mã nhà cung cấp này đã có, bạn phải nhập mã khác", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtMaNCC_ncc.Focus();
                return;
            }
            //if (txtGhichu_hh.Text == "")
            //{
            //sql = "INSERT INTO hanghoa VALUES(N'" +
            //txtMahang_hh.Text + "',N'" + txtTenhang_hh.Text + "',N'" + txtGiaban_hh.Text + "',N'" + txtDonvitinh_hh.Text + "',N'"
            //+ cboManhacc_hh.SelectedValue.ToString() + "',N'" + txtSoluong_hh.Text + "',N'" + txtGianhap_hh.Text + "',N'" + "')";
            //}
            //else {
            sql = "INSERT INTO nhacungcap VALUES(N'" +
            txtMaNCC_ncc.Text + "',N'" + txtTenNCC_ncc.Text + "',N'" + txtDiachi_ncc.Text + "',N'" + txtSDT_ncc.Text + "')"; 
            Control.Functions.RunSQL(sql); //Thực hiện câu lệnh sql
            LoadDataGridView_NCC(); //Nạp lại DataGridView
            ResetValue();
            btnXoa_hh.Enabled = true;
            btnThem_hh.Enabled = true;
            btnSua_hh.Enabled = true;
            btnHuy_hh.Enabled = false;
            btnLuu_hh.Enabled = false;
            txtMahang_hh.Enabled = false;
        }

        private void txtDiachi_nv_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtNgaysinh_nv_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void label17_Click(object sender, EventArgs e)
        {

        }

        private void txtTennhanvien_nv_TextChanged(object sender, EventArgs e)
        {

        }

        private void label19_Click(object sender, EventArgs e)
        {

        }

        private void label21_Click(object sender, EventArgs e)
        {

        }

        private void btnSua_ncc_Click(object sender, EventArgs e)
        {
            txtMaNCC_ncc.Enabled = false;
            string sql;
            if (tblNCC.Rows.Count == 0)
            {
                MessageBox.Show("Không còn dữ liệu", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            if (txtMaNCC_ncc.Text == "")
            {
                MessageBox.Show("Bạn phải chọn bản ghi cần sửa", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            if (txtMaNCC_ncc.Text.Trim().Length == 0 ||
                txtTenNCC_ncc.Text.Trim().Length == 0 || 
                txtDiachi_ncc.Text.Trim().Length == 0
                || txtSDT_ncc.Text.Trim().Length == 0)
            {
                MessageBox.Show("Vui lòng nhập đầy đủ thông tin", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            sql = "UPDATE nhacungcap SET tennhacc=N'" + txtTenNCC_ncc.Text.Trim().ToString() + "',diachi=N'" +
                txtDiachi_ncc.Text.Trim().ToString() + "',SDT=N'" + txtSDT_ncc.Text.Trim().ToString() + 
                "' WHERE Manhacc=N'" + txtMaNCC_ncc.Text + "'";
            Control.Functions.RunSQL(sql);
            LoadDataGridView_NCC();
            MessageBox.Show("Cập nhật thành công", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            ResetValues_NCC();
            btnHuy_ncc.Enabled = false;
            btnThem_ncc.Enabled = true;
        }

        private void dataGridView_ncc_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (btnThem_ncc.Enabled == false)
            {
                MessageBox.Show("Đang ở chế độ thêm mới!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtMaNCC_ncc.Focus();
                return;
            }
            if (tblNCC.Rows.Count == 0)
            {
                MessageBox.Show("Không có dữ liệu!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            txtMaNCC_ncc.Text = dataGridView_ncc.CurrentRow.Cells["Manhacc"].Value.ToString();
            txtTenNCC_ncc.Text = dataGridView_ncc.CurrentRow.Cells["Tennhacc"].Value.ToString();

            txtDiachi_ncc.Text = dataGridView_ncc.CurrentRow.Cells["Diachi"].Value.ToString();
            txtSDT_ncc.Text = dataGridView_ncc.CurrentRow.Cells["SDT"].Value.ToString();

            btnSua_ncc.Enabled = true;
            btnXoa_ncc.Enabled = true;
        }

        private void btnXoa_ncc_Click(object sender, EventArgs e)
        {
            string sql;
            if (tblNCC.Rows.Count == 0)
            {
                MessageBox.Show("Không có dữ liệu", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            if (txtMaNCC_ncc.Text.Trim() == "")
            {
                MessageBox.Show("Bạn chưa chọn nhà cung cấp nào", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            if (MessageBox.Show("Bạn có muốn xoá nhà cung cấp này không?", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                sql = "DELETE nhacungcap WHERE Manhacc=N'" + txtMaNCC_ncc.Text + "'";
                Control.Functions.RunSqlDel(sql);
                LoadDataGridView_NCC();
                ResetValues_NCC();
                MessageBox.Show("Xóa thành công", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                btnThem_ncc.Enabled = true;
                btnSua_ncc.Enabled = false;
                btnXoa_ncc.Enabled = false;
                btnLuu_ncc.Enabled = false;
                btnHuy_ncc.Enabled = false;
            }
        }

        private void cboMa_ncc_DropDown(object sender, EventArgs e)
        {
            //Functions.FillCombo("SELECT manhacc FROM nhacungcap", cboMa_ncc, "Manhacc", "Manhacc");
            //cboMa_ncc.SelectedIndex = -1;
        }
        DataTable nhacc;
        private void btnTimkiem_ncc_Click(object sender, EventArgs e)
        {
            if (txtTenncc_tk.Text == "")
            {
                MessageBox.Show("Bạn phải chọn một mã nhà cung cấp để tìm", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtTenncc_tk.Focus();
                return;
            }
            

            ConnectToSQL.Connect();
            string sql = "SELECT * from nhacungcap where tennhacc Like N'%" + txtTenncc_tk.Text + "%'";
            nhacc = Functions.GetDataToTable(sql);
            dataGridView_ncc.DataSource = nhacc;
        }

        private void btnTimkiem_hd_Click_1(object sender, EventArgs e)
        {
            TimKiemHD frm = new TimKiemHD(); //Khởi tạo đối tượng
            frm.Show();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void cboNam_DropDown(object sender, EventArgs e)
        {
            //Functions.FillCombo_nam("SELECT YEAR(Ngayban) FROM hoadon_ban", cboNam, "year(ngayban)");
            //cboNam.SelectedIndex = -1;
        }
        string tam = "", tam1 = "", bangtam2 = "", bangtam = "", bangtam1 = "";
        private void btnThongKe_Click(object sender, EventArgs e)
        {
            string[] d = DateTime.Now.ToLongTimeString().Split(':');
            
            tam = "bang_" + d[2];
            //MessageBox.Show("aa"+tam);
            bangtam = tam.Substring(0, 7);
            if (txtThang.Text == "" || cboNam.SelectedItem == "") {
                MessageBox.Show("Bạn phải chọn năm và tháng");
                txtThang.Focus();
                return;
            }
            //MessageBox.Show("a" + cboNam.SelectedValue.ToString());
            if (txtNgay.Text == "")
            {
                string str = "select SUM(thanhtien) from HOADON_BAN  WHERE YEAR(ngayban) = " + cboNam.SelectedItem + " AND MONTH(ngayban) = " + txtThang.Text + "";
                lblTien.Text = Functions.GetFieldValues(str);
                lblTien.Enabled = false;
                //MessageBox.Show(bangtam);
                string str1 = "select  a.mahh, a.tenhh, b.soluong*b.DONGIA as tienban, b.SOLUONG*a.GIANHAP as tienmua,  b.soluong*b.DONGIA - b.SOLUONG*a.GIANHAP as loi into " + bangtam + " from HANGHOA a join CHITIETHOADON_BAN b on a.MAHH = b.MAHH join hoadon_ban c on b.MaHD_ban = c.MaHD_ban WHERE YEAR(c.ngayban) = " + cboNam.SelectedItem + " AND MONTH(c.ngayban) = " + txtThang.Text + "";
                SqlCommand cmd; //Đối tượng thuộc lớp SqlCommand
                cmd = new SqlCommand();
                cmd.Connection = Control.ConnectToSQL.con; //Gán kết nối
                cmd.CommandText = str1; //Gán lệnh SQL
                try
                {
                    cmd.ExecuteNonQuery(); //Thực hiện câu lệnh SQL
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString());
                }
                cmd.Dispose();//Giải phóng bộ nhớ
                cmd = null;
                string str2 = "select  SUM(loi) from " + bangtam;
                lblLoi.Text = Functions.GetFieldValues(str2);
                lblLoi.Enabled = false;
                btnThongKe.Enabled = false;
                string del = "DROP table "+bangtam ;
                Control.Functions.RunSQL(del);
            }
            else {
                string str = "select SUM(thanhtien) from HOADON_BAN  WHERE YEAR(ngayban) = " + cboNam.SelectedItem + " AND MONTH(ngayban) = " + txtThang.Text + " AND DAY(ngayban) = " +txtNgay.Text+ "";
                lblTien.Text = Functions.GetFieldValues(str);
                lblTien.Enabled = false;
                //MessageBox.Show(bangtam);
                string str1 = "select  a.mahh, a.tenhh, b.soluong*b.DONGIA as tienban, b.SOLUONG*a.GIANHAP as tienmua,  b.soluong*b.DONGIA - b.SOLUONG*a.GIANHAP as loi into " + bangtam + " from HANGHOA a join CHITIETHOADON_BAN b on a.MAHH = b.MAHH join hoadon_ban c on b.MaHD_ban = c.MaHD_ban WHERE YEAR(c.ngayban) = " + cboNam.SelectedItem + " AND MONTH(c.ngayban) = " + txtThang.Text + "AND DAY(ngayban) = " +txtNgay.Text+"";
                SqlCommand cmd; //Đối tượng thuộc lớp SqlCommand
                cmd = new SqlCommand();
                cmd.Connection = Control.ConnectToSQL.con; //Gán kết nối
                cmd.CommandText = str1; //Gán lệnh SQL
                try
                {
                    cmd.ExecuteNonQuery(); //Thực hiện câu lệnh SQL
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString());
                }
                cmd.Dispose();//Giải phóng bộ nhớ
                cmd = null;
                string str2 = "select  SUM(loi) from " + bangtam;
                lblLoi.Text = Functions.GetFieldValues(str2);
                lblLoi.Enabled = false;
                btnThongKe.Enabled = false;
                string del = "DROP table "+bangtam;
                Control.Functions.RunSQL(del);
            }
        }

        private void btnThongke_hh_Click(object sender, EventArgs e)
        {
            string[] d1 = DateTime.Now.ToLongTimeString().Split(':');
            //MessageBox.Show("test" + d1[2]);
            tam1= "bang1_" + d1[2];
            bangtam1 = tam1.Substring(0, 7);
            
            //string[] dw = DateTime.Now.ToLongTimeString().Split(':');

            //bangtam2 = "bang2_" + d[1];
            if (txtThang_hh.Text == "" || cboNam_hh.SelectedItem == "")
            {
                MessageBox.Show("Bạn phải nhập đầy đủ điều kiện");
                txtThang_hh.Focus();
                return;
            }
            if (txtNgay_hh.Text == "")
            {
                LoadDataGridView_tkhh_thang();
                btnThongke_hh.Enabled = false;
                string del = "drop table "+bangtam1;
                Control.Functions.RunSQL(del);
            }
            else {
                LoadDataGridView_tkhh_ngay();
                btnThongke_hh.Enabled = false;
                string del = "drop table "+bangtam1;
                Control.Functions.RunSQL(del);
            }
        }
        public void LoadDataGridView_tkhh_thang()
        {
            string sql, sql1;
            sql = "select a.mahh as mahh, a.tenhh as tenhh, a.soluong as slcon, b.soluong as slban into " +bangtam1+ " from HANGHOA a join CHITIETHOADON_BAN b on a.MAHH = b.MAHH join HOADON_BAN c on b.MAHD_Ban = c.MAHD_BAN  WHERE YEAR(c.ngayban) = " + cboNam_hh.SelectedItem + " AND MONTH(c.ngayban) = " + txtThang_hh.Text + "";
            Control.Functions.RunSQL(sql);
            sql1 = "select mahh, tenhh, slcon, SUM(slban) as slban from "+bangtam1+" group by mahh, tenhh, slcon";
            tblTKHH = Functions.GetDataToTable(sql1); //lấy dữ liệu
            dgvhang_tk.DataSource = tblTKHH;
            dgvhang_tk.Columns[0].HeaderText = "Mã hàng hóa";
            dgvhang_tk.Columns[1].HeaderText = "Tên hàng hóa";
            dgvhang_tk.Columns[2].HeaderText = "Số lượng còn lại";
            dgvhang_tk.Columns[3].HeaderText = "Số lượng đã bán";
            dgvhang_tk.Columns[0].Width = 100;
            dgvhang_tk.Columns[1].Width = 170;
            dgvhang_tk.Columns[2].Width = 120;
            dgvhang_tk.Columns[3].Width = 120;

            dgvhang_tk.AllowUserToAddRows = false;
            dgvhang_tk.EditMode = DataGridViewEditMode.EditProgrammatically;
        }
        public void LoadDataGridView_tkhh_ngay()
        {
            string sql, sql1;
            sql = "select a.mahh as mahh, a.tenhh as tenhh, a.soluong as slcon, b.soluong as slban into " + bangtam1 + " from HANGHOA a join CHITIETHOADON_BAN b on a.MAHH = b.MAHH join HOADON_BAN c on b.MAHD_Ban = c.MAHD_BAN  WHERE YEAR(c.ngayban) = " + cboNam_hh.SelectedItem + " AND MONTH(c.ngayban) = " + txtThang_hh.Text + " AND DAY(ngayban) = " + txtNgay_hh.Text + "";
            Control.Functions.RunSQL(sql);
            sql1 = "select mahh, tenhh, slcon, SUM(slban) as slban from " + bangtam1 + " group by mahh, tenhh, slcon";
            tblTKHH = Functions.GetDataToTable(sql1); //lấy dữ liệu
            dgvhang_tk.DataSource = tblTKHH;
            dgvhang_tk.Columns[0].HeaderText = "Mã hàng hóa";
            dgvhang_tk.Columns[1].HeaderText = "Tên hàng hóa";
            dgvhang_tk.Columns[2].HeaderText = "Số lượng còn lại";
            dgvhang_tk.Columns[3].HeaderText = "Số lượng đã bán";
            dgvhang_tk.Columns[0].Width = 100;
            dgvhang_tk.Columns[1].Width = 170;
            dgvhang_tk.Columns[2].Width = 120;
            dgvhang_tk.Columns[3].Width = 120;

            dgvhang_tk.AllowUserToAddRows = false;
            dgvhang_tk.EditMode = DataGridViewEditMode.EditProgrammatically;
        }

        private void btnChonlai_Click(object sender, EventArgs e)
        {
            btnThongKe.Enabled = true;
            cboNam.SelectedIndex = -1;
            txtThang.Text = "";
            txtNgay.Text = "";
        }

        private void btnTklai_Click(object sender, EventArgs e)
        {
            btnThongke_hh.Enabled = true;
            cboNam_hh.SelectedIndex = -1;
            txtThang_hh.Text = "";
            txtNgay_hh.Text = "";
            dgvhang_tk.DataSource = null;
        }
   }
}



























