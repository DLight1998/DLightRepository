﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using QuanLyBanHang.Control;

namespace QuanLyBanHang.View
{
    public partial class TimKiemHD : Form
    {
        DataTable tblHDB; //Hoá đơn bán
        public TimKiemHD()
        {
            InitializeComponent();
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void TimKiemHD_Load(object sender, EventArgs e)
        {
            ResetValues();
            dgvHD.DataSource = null;
        }
        private void ResetValues()
        {
            txtMahoadon.Text = "";
            txtThang.Text = "";
            txtNam.Text = "";
            txtManv.Text = "";
            txtTongtien.Text = "";
            txtMahoadon.Focus();
        }

        private void btnTim_Click(object sender, EventArgs e)
        {
            string sql;
            if ((txtMahoadon.Text == "") && (txtThang.Text == "") && (txtNam.Text == "") &&
               (txtManv.Text == "") && (txtTongtien.Text == ""))
            {
                MessageBox.Show("Hãy nhập một điều kiện tìm kiếm!!!", "Yêu cầu ...", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            sql = "SELECT * FROM Hoadon_ban WHERE 1=1";
            if (txtMahoadon.Text != "")
                sql = sql + " AND MaHD_Ban Like N'%" + txtMahoadon.Text + "%'";
            if (txtThang.Text != "")
                sql = sql + " AND MONTH(Ngayban) =" + txtThang.Text;
            if (txtNam.Text != "")
                sql = sql + " AND YEAR(Ngayban) =" + txtNam.Text;
            if (txtManv.Text != "")
                sql = sql + " AND Manv Like N'%" + txtManv.Text + "%'";
            if (txtTongtien.Text != "")
                sql = sql + " AND Thanhtien <=" + txtTongtien.Text;
            tblHDB = Control.Functions.GetDataToTable(sql);
            if (tblHDB.Rows.Count == 0)
            {
                MessageBox.Show("Không có bản ghi thỏa mãn điều kiện!!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
                MessageBox.Show("Có " + tblHDB.Rows.Count + " bản ghi thỏa mãn điều kiện!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            dgvHD.DataSource = tblHDB;
            LoadDataGridView();
        }
        private void LoadDataGridView()
        {
            dgvHD.Columns[0].HeaderText = "Mã HĐB";
            dgvHD.Columns[1].HeaderText = "Mã nhân viên";
            dgvHD.Columns[2].HeaderText = "Ngày bán";
            //dgvHD.Columns[3].HeaderText = "Mã khách";
            dgvHD.Columns[3].HeaderText = "Tổng tiền";
            dgvHD.Columns[0].Width = 150;
            dgvHD.Columns[1].Width = 100;
            dgvHD.Columns[2].Width = 80;
            //dgvHD.Columns[3].Width = 80;
            dgvHD.Columns[3].Width = 80;
            dgvHD.AllowUserToAddRows = false;
            dgvHD.EditMode = DataGridViewEditMode.EditProgrammatically;
        }

        private void btnTimlai_Click(object sender, EventArgs e)
        {
            ResetValues();
            dgvHD.DataSource = null;
        }

        private void txtTongtien_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (((e.KeyChar >= '0') && (e.KeyChar <= '9')) || (Convert.ToInt32(e.KeyChar) == 8))
                e.Handled = false;
            else
                e.Handled = true;
        }

        private void dgvHD_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dgvHD_DoubleClick(object sender, EventArgs e)
        {
            string mahd;
            if (MessageBox.Show("Bạn có muốn hiển thị thông tin chi tiết?", "Xác nhận", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                mahd = dgvHD.CurrentRow.Cells["MaHD_Ban"].Value.ToString();
                frmMain frm = new frmMain();
                frm.txtMahoadon_hd.Text = mahd;
                frm.StartPosition = FormStartPosition.CenterScreen;
                frm.ShowDialog();
                //frm.txtSoluong_hd.Focus();
            }
        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
