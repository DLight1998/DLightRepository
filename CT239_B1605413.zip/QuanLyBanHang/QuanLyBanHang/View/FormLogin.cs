﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace QuanLyBanHang.View
{
    public partial class FormLogin : Form
    {
        public FormLogin()
        {
            InitializeComponent();
        }
        public static string ten, mk;
        
        private void btnDangnhap_Click(object sender, EventArgs e)
        {
            if (txtTendangnhap.Text == "" || txtMatkhau.Text == "")
            {
                MessageBox.Show("Bạn phải nhập đầy đủ tên đăng nhập và mật khẩu", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtTendangnhap.Focus();
                
            }
            
            else if(txtTendangnhap.Text == "nhanvien" && txtMatkhau.Text == "nhanvien"){
                ten = "nhanvien";
                mk = "nhanvien";
                frmMain frmmain = new frmMain(); //Khởi tạo đối tượng
                frmmain.Show();
                this.Hide();
                
            }
            else if (txtTendangnhap.Text == "quanly" && txtMatkhau.Text == "quanly")
            {
                frmMain frmMain = new frmMain(); //Khởi tạo đối tượng
                frmMain.Show();
                this.Close();
                //ten = "quanly";
                //mk = "quanly";
            }
            else if(txtTendangnhap.Text != "nhanvien" || txtMatkhau.Text != "nhanvien" || txtTendangnhap.Text != "quanly" || txtMatkhau.Text != "quanly")
            {
                MessageBox.Show("Bạn đã nhập sai tên đăng nhập hoặc mật khẩu", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtTendangnhap.Focus();
            }  
        }
    }
}
