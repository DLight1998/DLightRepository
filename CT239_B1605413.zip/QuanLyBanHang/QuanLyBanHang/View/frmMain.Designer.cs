﻿namespace QuanLyBanHang.View
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMain));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.label26 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.txtTenhh_tk = new System.Windows.Forms.TextBox();
            this.btnTimkiem_hh = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.dataGridView_hh = new System.Windows.Forms.DataGridView();
            this.btnLuu_hh = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.cboManhacc_hh = new System.Windows.Forms.ComboBox();
            this.txtGhichu_hh = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.txtGiaban_hh = new System.Windows.Forms.TextBox();
            this.txtSoluong_hh = new System.Windows.Forms.TextBox();
            this.txtGianhap_hh = new System.Windows.Forms.TextBox();
            this.txtDonvitinh_hh = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txtTenhang_hh = new System.Windows.Forms.TextBox();
            this.txtMahang_hh = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnHuy_hh = new System.Windows.Forms.Button();
            this.btnSua_hh = new System.Windows.Forms.Button();
            this.btnXoa_hh = new System.Windows.Forms.Button();
            this.btnThem_hh = new System.Windows.Forms.Button();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.label44 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.btnTimkiem_hd = new System.Windows.Forms.Button();
            this.btnIn_hd = new System.Windows.Forms.Button();
            this.btnLuu_hd = new System.Windows.Forms.Button();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.lblBangchu = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.lbltongtienbangchu = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.txtTongTien_hd = new System.Windows.Forms.TextBox();
            this.label39 = new System.Windows.Forms.Label();
            this.dataGridView_hd = new System.Windows.Forms.DataGridView();
            this.txtTenhang_hd = new System.Windows.Forms.TextBox();
            this.cboMahanghoa_hd = new System.Windows.Forms.ComboBox();
            this.txtGiamgia_hd = new System.Windows.Forms.TextBox();
            this.txtThanhtien_hd = new System.Windows.Forms.TextBox();
            this.txtDongia_hd = new System.Windows.Forms.TextBox();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.txtSoluong_hd = new System.Windows.Forms.TextBox();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.cboManhanvien_hd = new System.Windows.Forms.ComboBox();
            this.txtTennhanvien_hd = new System.Windows.Forms.TextBox();
            this.txtNgayban_hd = new System.Windows.Forms.TextBox();
            this.txtMahoadon_hd = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.btnThem_hd = new System.Windows.Forms.Button();
            this.btnHuy_hd = new System.Windows.Forms.Button();
            this.btnXoa_hd = new System.Windows.Forms.Button();
            this.tabPage_ncc = new System.Windows.Forms.TabPage();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.dataGridView_ncc = new System.Windows.Forms.DataGridView();
            this.btnLuu_ncc = new System.Windows.Forms.Button();
            this.btnHuy_ncc = new System.Windows.Forms.Button();
            this.btnXoa_ncc = new System.Windows.Forms.Button();
            this.btnSua_ncc = new System.Windows.Forms.Button();
            this.btnThem_ncc = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.txtTenncc_tk = new System.Windows.Forms.TextBox();
            this.btnTimkiem_ncc = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.txtSDT_ncc = new System.Windows.Forms.TextBox();
            this.txtDiachi_ncc = new System.Windows.Forms.TextBox();
            this.txtTenNCC_ncc = new System.Windows.Forms.TextBox();
            this.txtMaNCC_ncc = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.dataGridView_nv = new System.Windows.Forms.DataGridView();
            this.btnLuu_nv = new System.Windows.Forms.Button();
            this.btnHuy_nv = new System.Windows.Forms.Button();
            this.btnXoa_nv = new System.Windows.Forms.Button();
            this.btnSua_nv = new System.Windows.Forms.Button();
            this.btnThem_nv = new System.Windows.Forms.Button();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.txtTennv_tk = new System.Windows.Forms.TextBox();
            this.btnTimkiem_nv = new System.Windows.Forms.Button();
            this.label12 = new System.Windows.Forms.Label();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.txtSDT_nv = new System.Windows.Forms.TextBox();
            this.txtNgaysinh_nv = new System.Windows.Forms.MaskedTextBox();
            this.chkGioitinh_nv = new System.Windows.Forms.CheckBox();
            this.txtDiachi_nv = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.txtTennhanvien_nv = new System.Windows.Forms.TextBox();
            this.txtManhanvien_nv = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnTklai = new System.Windows.Forms.Button();
            this.dgvhang_tk = new System.Windows.Forms.DataGridView();
            this.txtThang_hh = new System.Windows.Forms.TextBox();
            this.label56 = new System.Windows.Forms.Label();
            this.label57 = new System.Windows.Forms.Label();
            this.btnThongke_hh = new System.Windows.Forms.Button();
            this.cboNam_hh = new System.Windows.Forms.ComboBox();
            this.label60 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnChonlai = new System.Windows.Forms.Button();
            this.label51 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.lblLoi = new System.Windows.Forms.Label();
            this.lblTien = new System.Windows.Forms.Label();
            this.txtThang = new System.Windows.Forms.TextBox();
            this.label50 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.btnThongKe = new System.Windows.Forms.Button();
            this.cboNam = new System.Windows.Forms.ComboBox();
            this.label46 = new System.Windows.Forms.Label();
            this.button13 = new System.Windows.Forms.Button();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.dataGridView4 = new System.Windows.Forms.DataGridView();
            this.dataGridView5 = new System.Windows.Forms.DataGridView();
            this.button26 = new System.Windows.Forms.Button();
            this.textBox32 = new System.Windows.Forms.TextBox();
            this.label37 = new System.Windows.Forms.Label();
            this.txtNgay = new System.Windows.Forms.TextBox();
            this.label49 = new System.Windows.Forms.Label();
            this.txtNgay_hh = new System.Windows.Forms.TextBox();
            this.label53 = new System.Windows.Forms.Label();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_hh)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.groupBox11.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_hd)).BeginInit();
            this.groupBox10.SuspendLayout();
            this.tabPage_ncc.SuspendLayout();
            this.groupBox6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_ncc)).BeginInit();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.groupBox9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_nv)).BeginInit();
            this.groupBox8.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvhang_tk)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView5)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage_ncc);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl1.ItemSize = new System.Drawing.Size(100, 35);
            this.tabControl1.Location = new System.Drawing.Point(-4, 0);
            this.tabControl1.Margin = new System.Windows.Forms.Padding(3, 0, 3, 3);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.Padding = new System.Drawing.Point(20, 6);
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(966, 502);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("tabPage1.BackgroundImage")));
            this.tabPage1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.tabPage1.Controls.Add(this.label26);
            this.tabPage1.Controls.Add(this.label24);
            this.tabPage1.Controls.Add(this.label23);
            this.tabPage1.Controls.Add(this.label43);
            this.tabPage1.Controls.Add(this.label42);
            this.tabPage1.ForeColor = System.Drawing.SystemColors.Desktop;
            this.tabPage1.Location = new System.Drawing.Point(4, 39);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(958, 459);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Trang chủ";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(583, 180);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(300, 16);
            this.label26.TabIndex = 4;
            this.label26.Text = "Giảng viên hướng dẫn: Ths. GVC Võ Huỳnh Trâm ";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(583, 152);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(180, 16);
            this.label24.TabIndex = 3;
            this.label24.Text = "Học kỳ 1, năm học 2019-2020";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(583, 124);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(262, 16);
            this.label23.TabIndex = 2;
            this.label23.Text = "Niên luận cơ sở ngành Kỹ Thuật Phần Mềm";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label43.Location = new System.Drawing.Point(583, 210);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(266, 16);
            this.label43.TabIndex = 1;
            this.label43.Text = "Sinh viên thực hiện: Thạch Trần Nhật Quang";
            this.label43.Click += new System.EventHandler(this.label43_Click);
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Font = new System.Drawing.Font("Pleiku", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label42.Location = new System.Drawing.Point(262, 55);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(549, 36);
            this.label42.TabIndex = 0;
            this.label42.Text = "PHAN MEM QUAN LY BAN HANG";
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.PaleTurquoise;
            this.tabPage2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.tabPage2.Controls.Add(this.groupBox5);
            this.tabPage2.Controls.Add(this.groupBox4);
            this.tabPage2.Controls.Add(this.btnLuu_hh);
            this.tabPage2.Controls.Add(this.groupBox1);
            this.tabPage2.Controls.Add(this.btnHuy_hh);
            this.tabPage2.Controls.Add(this.btnSua_hh);
            this.tabPage2.Controls.Add(this.btnXoa_hh);
            this.tabPage2.Controls.Add(this.btnThem_hh);
            this.tabPage2.Location = new System.Drawing.Point(4, 39);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(958, 459);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Quản Lý Hàng Hóa";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.txtTenhh_tk);
            this.groupBox5.Controls.Add(this.btnTimkiem_hh);
            this.groupBox5.Controls.Add(this.label10);
            this.groupBox5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox5.Location = new System.Drawing.Point(685, 153);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(270, 90);
            this.groupBox5.TabIndex = 22;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Tìm kiếm";
            // 
            // txtTenhh_tk
            // 
            this.txtTenhh_tk.Location = new System.Drawing.Point(111, 18);
            this.txtTenhh_tk.Name = "txtTenhh_tk";
            this.txtTenhh_tk.Size = new System.Drawing.Size(150, 22);
            this.txtTenhh_tk.TabIndex = 19;
            // 
            // btnTimkiem_hh
            // 
            this.btnTimkiem_hh.Image = ((System.Drawing.Image)(resources.GetObject("btnTimkiem_hh.Image")));
            this.btnTimkiem_hh.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnTimkiem_hh.Location = new System.Drawing.Point(164, 46);
            this.btnTimkiem_hh.Name = "btnTimkiem_hh";
            this.btnTimkiem_hh.Size = new System.Drawing.Size(97, 36);
            this.btnTimkiem_hh.TabIndex = 18;
            this.btnTimkiem_hh.Text = "Tìm Kiếm";
            this.btnTimkiem_hh.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnTimkiem_hh.UseVisualStyleBackColor = true;
            this.btnTimkiem_hh.Click += new System.EventHandler(this.btnTimkiem_hh_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(26, 21);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(65, 16);
            this.label10.TabIndex = 16;
            this.label10.Text = "Tên hàng";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.dataGridView_hh);
            this.groupBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox4.Location = new System.Drawing.Point(6, 241);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(950, 218);
            this.groupBox4.TabIndex = 21;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Danh sách hàng hóa";
            // 
            // dataGridView_hh
            // 
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridView_hh.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView_hh.BackgroundColor = System.Drawing.SystemColors.InactiveBorder;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView_hh.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridView_hh.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView_hh.DefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridView_hh.GridColor = System.Drawing.SystemColors.ControlText;
            this.dataGridView_hh.Location = new System.Drawing.Point(0, 21);
            this.dataGridView_hh.Name = "dataGridView_hh";
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView_hh.RowHeadersDefaultCellStyle = dataGridViewCellStyle4;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridView_hh.RowsDefaultCellStyle = dataGridViewCellStyle5;
            this.dataGridView_hh.Size = new System.Drawing.Size(940, 197);
            this.dataGridView_hh.TabIndex = 0;
            this.dataGridView_hh.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView_hh_Click);
            // 
            // btnLuu_hh
            // 
            this.btnLuu_hh.Image = ((System.Drawing.Image)(resources.GetObject("btnLuu_hh.Image")));
            this.btnLuu_hh.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnLuu_hh.Location = new System.Drawing.Point(598, 174);
            this.btnLuu_hh.Name = "btnLuu_hh";
            this.btnLuu_hh.Size = new System.Drawing.Size(75, 38);
            this.btnLuu_hh.TabIndex = 13;
            this.btnLuu_hh.Text = "Lưu";
            this.btnLuu_hh.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnLuu_hh.UseVisualStyleBackColor = true;
            this.btnLuu_hh.Click += new System.EventHandler(this.btnLuu_hh_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.cboManhacc_hh);
            this.groupBox1.Controls.Add(this.txtGhichu_hh);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.txtGiaban_hh);
            this.groupBox1.Controls.Add(this.txtSoluong_hh);
            this.groupBox1.Controls.Add(this.txtGianhap_hh);
            this.groupBox1.Controls.Add(this.txtDonvitinh_hh);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.txtTenhang_hh);
            this.groupBox1.Controls.Add(this.txtMahang_hh);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(6, 6);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(949, 147);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Nhập thông tin hàng hóa";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // cboManhacc_hh
            // 
            this.cboManhacc_hh.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboManhacc_hh.FormattingEnabled = true;
            this.cboManhacc_hh.Location = new System.Drawing.Point(776, 40);
            this.cboManhacc_hh.Name = "cboManhacc_hh";
            this.cboManhacc_hh.Size = new System.Drawing.Size(153, 24);
            this.cboManhacc_hh.TabIndex = 7;
            this.cboManhacc_hh.SelectedIndexChanged += new System.EventHandler(this.cboManhacc_hh_SelectedIndexChanged);
            // 
            // txtGhichu_hh
            // 
            this.txtGhichu_hh.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtGhichu_hh.Location = new System.Drawing.Point(776, 100);
            this.txtGhichu_hh.Name = "txtGhichu_hh";
            this.txtGhichu_hh.Size = new System.Drawing.Size(133, 22);
            this.txtGhichu_hh.TabIndex = 8;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(665, 105);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(52, 16);
            this.label7.TabIndex = 13;
            this.label7.Text = "Ghi chú";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(665, 44);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(91, 16);
            this.label8.TabIndex = 12;
            this.label8.Text = "Nhà cung cấp";
            // 
            // txtGiaban_hh
            // 
            this.txtGiaban_hh.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtGiaban_hh.Location = new System.Drawing.Point(317, 103);
            this.txtGiaban_hh.Name = "txtGiaban_hh";
            this.txtGiaban_hh.Size = new System.Drawing.Size(95, 22);
            this.txtGiaban_hh.TabIndex = 4;
            // 
            // txtSoluong_hh
            // 
            this.txtSoluong_hh.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSoluong_hh.Location = new System.Drawing.Point(317, 40);
            this.txtSoluong_hh.Name = "txtSoluong_hh";
            this.txtSoluong_hh.Size = new System.Drawing.Size(64, 22);
            this.txtSoluong_hh.TabIndex = 3;
            // 
            // txtGianhap_hh
            // 
            this.txtGianhap_hh.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtGianhap_hh.Location = new System.Drawing.Point(525, 102);
            this.txtGianhap_hh.Name = "txtGianhap_hh";
            this.txtGianhap_hh.Size = new System.Drawing.Size(100, 22);
            this.txtGianhap_hh.TabIndex = 6;
            // 
            // txtDonvitinh_hh
            // 
            this.txtDonvitinh_hh.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDonvitinh_hh.Location = new System.Drawing.Point(525, 40);
            this.txtDonvitinh_hh.Name = "txtDonvitinh_hh";
            this.txtDonvitinh_hh.Size = new System.Drawing.Size(100, 22);
            this.txtDonvitinh_hh.TabIndex = 5;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(438, 105);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(62, 16);
            this.label5.TabIndex = 7;
            this.label5.Text = "Giá nhập";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(438, 44);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(68, 16);
            this.label6.TabIndex = 6;
            this.label6.Text = "Đơn vị tính";
            // 
            // txtTenhang_hh
            // 
            this.txtTenhang_hh.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTenhang_hh.Location = new System.Drawing.Point(85, 103);
            this.txtTenhang_hh.Name = "txtTenhang_hh";
            this.txtTenhang_hh.Size = new System.Drawing.Size(134, 22);
            this.txtTenhang_hh.TabIndex = 2;
            // 
            // txtMahang_hh
            // 
            this.txtMahang_hh.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMahang_hh.Location = new System.Drawing.Point(85, 40);
            this.txtMahang_hh.Name = "txtMahang_hh";
            this.txtMahang_hh.Size = new System.Drawing.Size(79, 22);
            this.txtMahang_hh.TabIndex = 1;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(238, 105);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(55, 16);
            this.label4.TabIndex = 3;
            this.label4.Text = "Giá bán";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(238, 44);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(61, 16);
            this.label3.TabIndex = 2;
            this.label3.Text = "Số lượng";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(14, 105);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "Tên hàng";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(14, 44);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(60, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Mã hàng";
            // 
            // btnHuy_hh
            // 
            this.btnHuy_hh.Image = ((System.Drawing.Image)(resources.GetObject("btnHuy_hh.Image")));
            this.btnHuy_hh.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnHuy_hh.Location = new System.Drawing.Point(459, 174);
            this.btnHuy_hh.Name = "btnHuy_hh";
            this.btnHuy_hh.Size = new System.Drawing.Size(75, 38);
            this.btnHuy_hh.TabIndex = 12;
            this.btnHuy_hh.Text = "Hủy";
            this.btnHuy_hh.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnHuy_hh.UseVisualStyleBackColor = true;
            this.btnHuy_hh.Click += new System.EventHandler(this.btnHuy_hh_Click);
            // 
            // btnSua_hh
            // 
            this.btnSua_hh.Image = ((System.Drawing.Image)(resources.GetObject("btnSua_hh.Image")));
            this.btnSua_hh.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSua_hh.Location = new System.Drawing.Point(161, 174);
            this.btnSua_hh.Name = "btnSua_hh";
            this.btnSua_hh.Size = new System.Drawing.Size(75, 38);
            this.btnSua_hh.TabIndex = 10;
            this.btnSua_hh.Text = "Sửa";
            this.btnSua_hh.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnSua_hh.UseVisualStyleBackColor = true;
            this.btnSua_hh.Click += new System.EventHandler(this.btnSua_hh_Click);
            // 
            // btnXoa_hh
            // 
            this.btnXoa_hh.Image = ((System.Drawing.Image)(resources.GetObject("btnXoa_hh.Image")));
            this.btnXoa_hh.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnXoa_hh.Location = new System.Drawing.Point(311, 174);
            this.btnXoa_hh.Name = "btnXoa_hh";
            this.btnXoa_hh.Size = new System.Drawing.Size(75, 38);
            this.btnXoa_hh.TabIndex = 11;
            this.btnXoa_hh.Text = "Xóa";
            this.btnXoa_hh.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnXoa_hh.UseVisualStyleBackColor = true;
            this.btnXoa_hh.Click += new System.EventHandler(this.btnXoa_hh_Click);
            // 
            // btnThem_hh
            // 
            this.btnThem_hh.Image = ((System.Drawing.Image)(resources.GetObject("btnThem_hh.Image")));
            this.btnThem_hh.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnThem_hh.Location = new System.Drawing.Point(23, 174);
            this.btnThem_hh.Name = "btnThem_hh";
            this.btnThem_hh.Size = new System.Drawing.Size(75, 38);
            this.btnThem_hh.TabIndex = 9;
            this.btnThem_hh.Text = "Thêm";
            this.btnThem_hh.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnThem_hh.UseVisualStyleBackColor = true;
            this.btnThem_hh.Click += new System.EventHandler(this.btnThem_hh_Click);
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.Color.PaleTurquoise;
            this.tabPage3.Controls.Add(this.label44);
            this.tabPage3.Controls.Add(this.label38);
            this.tabPage3.Controls.Add(this.btnTimkiem_hd);
            this.tabPage3.Controls.Add(this.btnIn_hd);
            this.tabPage3.Controls.Add(this.btnLuu_hd);
            this.tabPage3.Controls.Add(this.groupBox11);
            this.tabPage3.Controls.Add(this.groupBox10);
            this.tabPage3.Controls.Add(this.btnThem_hd);
            this.tabPage3.Controls.Add(this.btnHuy_hd);
            this.tabPage3.Controls.Add(this.btnXoa_hd);
            this.tabPage3.Location = new System.Drawing.Point(4, 39);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(958, 459);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Quản Lý Hóa Đơn";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(753, 291);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(159, 16);
            this.label44.TabIndex = 29;
            this.label44.Text = "form tìm kiếm hóa đơn";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(704, 261);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(247, 16);
            this.label38.TabIndex = 28;
            this.label38.Text = "Nhấn vào nút bên dưới để truy cập ";
            // 
            // btnTimkiem_hd
            // 
            this.btnTimkiem_hd.Image = ((System.Drawing.Image)(resources.GetObject("btnTimkiem_hd.Image")));
            this.btnTimkiem_hd.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnTimkiem_hd.Location = new System.Drawing.Point(741, 325);
            this.btnTimkiem_hd.Name = "btnTimkiem_hd";
            this.btnTimkiem_hd.Padding = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.btnTimkiem_hd.Size = new System.Drawing.Size(175, 49);
            this.btnTimkiem_hd.TabIndex = 27;
            this.btnTimkiem_hd.Text = "Tìm kiếm hóa đơn";
            this.btnTimkiem_hd.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnTimkiem_hd.UseVisualStyleBackColor = true;
            this.btnTimkiem_hd.Click += new System.EventHandler(this.btnTimkiem_hd_Click_1);
            // 
            // btnIn_hd
            // 
            this.btnIn_hd.Image = ((System.Drawing.Image)(resources.GetObject("btnIn_hd.Image")));
            this.btnIn_hd.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnIn_hd.Location = new System.Drawing.Point(765, 187);
            this.btnIn_hd.Name = "btnIn_hd";
            this.btnIn_hd.Padding = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.btnIn_hd.Size = new System.Drawing.Size(123, 38);
            this.btnIn_hd.TabIndex = 26;
            this.btnIn_hd.Text = "In hóa đơn";
            this.btnIn_hd.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnIn_hd.UseVisualStyleBackColor = true;
            this.btnIn_hd.Click += new System.EventHandler(this.btnIn_hd_Click);
            // 
            // btnLuu_hd
            // 
            this.btnLuu_hd.Image = ((System.Drawing.Image)(resources.GetObject("btnLuu_hd.Image")));
            this.btnLuu_hd.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnLuu_hd.Location = new System.Drawing.Point(741, 115);
            this.btnLuu_hd.Name = "btnLuu_hd";
            this.btnLuu_hd.Size = new System.Drawing.Size(75, 38);
            this.btnLuu_hd.TabIndex = 25;
            this.btnLuu_hd.Text = "Lưu";
            this.btnLuu_hd.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnLuu_hd.UseVisualStyleBackColor = true;
            this.btnLuu_hd.Click += new System.EventHandler(this.btnLuu_hd_Click);
            // 
            // groupBox11
            // 
            this.groupBox11.Controls.Add(this.lblBangchu);
            this.groupBox11.Controls.Add(this.label25);
            this.groupBox11.Controls.Add(this.label41);
            this.groupBox11.Controls.Add(this.lbltongtienbangchu);
            this.groupBox11.Controls.Add(this.label40);
            this.groupBox11.Controls.Add(this.txtTongTien_hd);
            this.groupBox11.Controls.Add(this.label39);
            this.groupBox11.Controls.Add(this.dataGridView_hd);
            this.groupBox11.Controls.Add(this.txtTenhang_hd);
            this.groupBox11.Controls.Add(this.cboMahanghoa_hd);
            this.groupBox11.Controls.Add(this.txtGiamgia_hd);
            this.groupBox11.Controls.Add(this.txtThanhtien_hd);
            this.groupBox11.Controls.Add(this.txtDongia_hd);
            this.groupBox11.Controls.Add(this.label31);
            this.groupBox11.Controls.Add(this.label32);
            this.groupBox11.Controls.Add(this.txtSoluong_hd);
            this.groupBox11.Controls.Add(this.label33);
            this.groupBox11.Controls.Add(this.label34);
            this.groupBox11.Controls.Add(this.label35);
            this.groupBox11.Controls.Add(this.label36);
            this.groupBox11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox11.Location = new System.Drawing.Point(6, 140);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Size = new System.Drawing.Size(692, 310);
            this.groupBox11.TabIndex = 2;
            this.groupBox11.TabStop = false;
            this.groupBox11.Text = "Thông tin mặt hàng";
            // 
            // lblBangchu
            // 
            this.lblBangchu.AutoSize = true;
            this.lblBangchu.Location = new System.Drawing.Point(484, 291);
            this.lblBangchu.Name = "lblBangchu";
            this.lblBangchu.Size = new System.Drawing.Size(0, 16);
            this.lblBangchu.TabIndex = 32;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(400, 291);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(76, 16);
            this.label25.TabIndex = 31;
            this.label25.Text = "Bằng chữ:";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label41.ForeColor = System.Drawing.SystemColors.Desktop;
            this.label41.Location = new System.Drawing.Point(17, 273);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(193, 16);
            this.label41.TabIndex = 30;
            this.label41.Text = "Nháy đúp một dòng để xóa";
            // 
            // lbltongtienbangchu
            // 
            this.lbltongtienbangchu.AutoSize = true;
            this.lbltongtienbangchu.Location = new System.Drawing.Point(38, 257);
            this.lbltongtienbangchu.Name = "lbltongtienbangchu";
            this.lbltongtienbangchu.Size = new System.Drawing.Size(0, 16);
            this.lbltongtienbangchu.TabIndex = 29;
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label40.Location = new System.Drawing.Point(610, 266);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(36, 16);
            this.label40.TabIndex = 28;
            this.label40.Text = "VNĐ";
            // 
            // txtTongTien_hd
            // 
            this.txtTongTien_hd.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTongTien_hd.Location = new System.Drawing.Point(502, 260);
            this.txtTongTien_hd.Name = "txtTongTien_hd";
            this.txtTongTien_hd.Size = new System.Drawing.Size(100, 22);
            this.txtTongTien_hd.TabIndex = 27;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.Location = new System.Drawing.Point(418, 263);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(73, 16);
            this.label39.TabIndex = 26;
            this.label39.Text = "Tổng tiền";
            // 
            // dataGridView_hd
            // 
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridView_hd.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle6;
            this.dataGridView_hd.BackgroundColor = System.Drawing.SystemColors.InactiveBorder;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle7.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView_hd.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle7;
            this.dataGridView_hd.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView_hd.DefaultCellStyle = dataGridViewCellStyle8;
            this.dataGridView_hd.Location = new System.Drawing.Point(14, 86);
            this.dataGridView_hd.Name = "dataGridView_hd";
            this.dataGridView_hd.Size = new System.Drawing.Size(657, 164);
            this.dataGridView_hd.TabIndex = 25;
            this.dataGridView_hd.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView_hd_CellDoubleClick);
            // 
            // txtTenhang_hd
            // 
            this.txtTenhang_hd.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTenhang_hd.Location = new System.Drawing.Point(314, 21);
            this.txtTenhang_hd.Name = "txtTenhang_hd";
            this.txtTenhang_hd.Size = new System.Drawing.Size(162, 22);
            this.txtTenhang_hd.TabIndex = 24;
            // 
            // cboMahanghoa_hd
            // 
            this.cboMahanghoa_hd.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboMahanghoa_hd.FormattingEnabled = true;
            this.cboMahanghoa_hd.Location = new System.Drawing.Point(88, 24);
            this.cboMahanghoa_hd.Name = "cboMahanghoa_hd";
            this.cboMahanghoa_hd.Size = new System.Drawing.Size(149, 24);
            this.cboMahanghoa_hd.TabIndex = 18;
            this.cboMahanghoa_hd.TextChanged += new System.EventHandler(this.cboMahanghoa_hd_TextChanged);
            // 
            // txtGiamgia_hd
            // 
            this.txtGiamgia_hd.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtGiamgia_hd.Location = new System.Drawing.Point(314, 55);
            this.txtGiamgia_hd.Name = "txtGiamgia_hd";
            this.txtGiamgia_hd.Size = new System.Drawing.Size(95, 22);
            this.txtGiamgia_hd.TabIndex = 23;
            this.txtGiamgia_hd.TextChanged += new System.EventHandler(this.txtGiamgia_hd_TextChanged);
            // 
            // txtThanhtien_hd
            // 
            this.txtThanhtien_hd.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtThanhtien_hd.Location = new System.Drawing.Point(571, 52);
            this.txtThanhtien_hd.Name = "txtThanhtien_hd";
            this.txtThanhtien_hd.Size = new System.Drawing.Size(100, 22);
            this.txtThanhtien_hd.TabIndex = 22;
            // 
            // txtDongia_hd
            // 
            this.txtDongia_hd.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDongia_hd.Location = new System.Drawing.Point(571, 21);
            this.txtDongia_hd.Name = "txtDongia_hd";
            this.txtDongia_hd.Size = new System.Drawing.Size(100, 22);
            this.txtDongia_hd.TabIndex = 21;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.Location = new System.Drawing.Point(482, 58);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(70, 16);
            this.label31.TabIndex = 20;
            this.label31.Text = "Thành tiền";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.Location = new System.Drawing.Point(482, 27);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(54, 16);
            this.label32.TabIndex = 19;
            this.label32.Text = "Đơn giá";
            // 
            // txtSoluong_hd
            // 
            this.txtSoluong_hd.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSoluong_hd.Location = new System.Drawing.Point(88, 57);
            this.txtSoluong_hd.Name = "txtSoluong_hd";
            this.txtSoluong_hd.Size = new System.Drawing.Size(94, 22);
            this.txtSoluong_hd.TabIndex = 18;
            this.txtSoluong_hd.TextChanged += new System.EventHandler(this.txtSoluong_hd_TextChanged);
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.Location = new System.Drawing.Point(243, 54);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(62, 16);
            this.label33.TabIndex = 16;
            this.label33.Text = "Giảm giá";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.Location = new System.Drawing.Point(243, 27);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(65, 16);
            this.label34.TabIndex = 15;
            this.label34.Text = "Tên hàng";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.Location = new System.Drawing.Point(16, 60);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(61, 16);
            this.label35.TabIndex = 14;
            this.label35.Text = "Số lượng";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label36.Location = new System.Drawing.Point(17, 30);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(63, 16);
            this.label36.TabIndex = 13;
            this.label36.Text = "Mặt hàng";
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.cboManhanvien_hd);
            this.groupBox10.Controls.Add(this.txtTennhanvien_hd);
            this.groupBox10.Controls.Add(this.txtNgayban_hd);
            this.groupBox10.Controls.Add(this.txtMahoadon_hd);
            this.groupBox10.Controls.Add(this.label27);
            this.groupBox10.Controls.Add(this.label28);
            this.groupBox10.Controls.Add(this.label29);
            this.groupBox10.Controls.Add(this.label30);
            this.groupBox10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox10.Location = new System.Drawing.Point(6, 6);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(692, 128);
            this.groupBox10.TabIndex = 1;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "Thông tin chung";
            // 
            // cboManhanvien_hd
            // 
            this.cboManhanvien_hd.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboManhanvien_hd.FormattingEnabled = true;
            this.cboManhanvien_hd.Location = new System.Drawing.Point(475, 40);
            this.cboManhanvien_hd.Name = "cboManhanvien_hd";
            this.cboManhanvien_hd.Size = new System.Drawing.Size(186, 24);
            this.cboManhanvien_hd.TabIndex = 16;
            this.cboManhanvien_hd.TextChanged += new System.EventHandler(this.cboManhanvien_hd_TextChanged);
            // 
            // txtTennhanvien_hd
            // 
            this.txtTennhanvien_hd.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTennhanvien_hd.Location = new System.Drawing.Point(475, 85);
            this.txtTennhanvien_hd.Name = "txtTennhanvien_hd";
            this.txtTennhanvien_hd.Size = new System.Drawing.Size(186, 22);
            this.txtTennhanvien_hd.TabIndex = 11;
            // 
            // txtNgayban_hd
            // 
            this.txtNgayban_hd.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNgayban_hd.Location = new System.Drawing.Point(136, 85);
            this.txtNgayban_hd.Name = "txtNgayban_hd";
            this.txtNgayban_hd.Size = new System.Drawing.Size(107, 22);
            this.txtNgayban_hd.TabIndex = 5;
            // 
            // txtMahoadon_hd
            // 
            this.txtMahoadon_hd.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMahoadon_hd.Location = new System.Drawing.Point(136, 40);
            this.txtMahoadon_hd.Name = "txtMahoadon_hd";
            this.txtMahoadon_hd.Size = new System.Drawing.Size(169, 22);
            this.txtMahoadon_hd.TabIndex = 4;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(366, 88);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(92, 16);
            this.label27.TabIndex = 3;
            this.label27.Text = "Tên nhân viên";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(366, 43);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(68, 16);
            this.label28.TabIndex = 2;
            this.label28.Text = "Nhân viên";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(38, 88);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(67, 16);
            this.label29.TabIndex = 1;
            this.label29.Text = "Ngày bán";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.Location = new System.Drawing.Point(38, 44);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(79, 16);
            this.label30.TabIndex = 0;
            this.label30.Text = "Mã hóa đơn";
            // 
            // btnThem_hd
            // 
            this.btnThem_hd.Image = ((System.Drawing.Image)(resources.GetObject("btnThem_hd.Image")));
            this.btnThem_hd.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnThem_hd.Location = new System.Drawing.Point(740, 32);
            this.btnThem_hd.Name = "btnThem_hd";
            this.btnThem_hd.Size = new System.Drawing.Size(75, 38);
            this.btnThem_hd.TabIndex = 21;
            this.btnThem_hd.Text = "Thêm";
            this.btnThem_hd.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnThem_hd.UseVisualStyleBackColor = true;
            this.btnThem_hd.Click += new System.EventHandler(this.btnThem_hd_Click);
            // 
            // btnHuy_hd
            // 
            this.btnHuy_hd.Image = ((System.Drawing.Image)(resources.GetObject("btnHuy_hd.Image")));
            this.btnHuy_hd.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnHuy_hd.Location = new System.Drawing.Point(837, 115);
            this.btnHuy_hd.Name = "btnHuy_hd";
            this.btnHuy_hd.Size = new System.Drawing.Size(75, 38);
            this.btnHuy_hd.TabIndex = 24;
            this.btnHuy_hd.Text = "Hủy";
            this.btnHuy_hd.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnHuy_hd.UseVisualStyleBackColor = true;
            // 
            // btnXoa_hd
            // 
            this.btnXoa_hd.Image = ((System.Drawing.Image)(resources.GetObject("btnXoa_hd.Image")));
            this.btnXoa_hd.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnXoa_hd.Location = new System.Drawing.Point(837, 32);
            this.btnXoa_hd.Name = "btnXoa_hd";
            this.btnXoa_hd.Size = new System.Drawing.Size(75, 38);
            this.btnXoa_hd.TabIndex = 22;
            this.btnXoa_hd.Text = "Xóa";
            this.btnXoa_hd.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnXoa_hd.UseVisualStyleBackColor = true;
            this.btnXoa_hd.Click += new System.EventHandler(this.btnXoa_hd_Click);
            // 
            // tabPage_ncc
            // 
            this.tabPage_ncc.BackColor = System.Drawing.Color.PaleTurquoise;
            this.tabPage_ncc.Controls.Add(this.groupBox6);
            this.tabPage_ncc.Controls.Add(this.btnLuu_ncc);
            this.tabPage_ncc.Controls.Add(this.btnHuy_ncc);
            this.tabPage_ncc.Controls.Add(this.btnXoa_ncc);
            this.tabPage_ncc.Controls.Add(this.btnSua_ncc);
            this.tabPage_ncc.Controls.Add(this.btnThem_ncc);
            this.tabPage_ncc.Controls.Add(this.groupBox3);
            this.tabPage_ncc.Controls.Add(this.groupBox2);
            this.tabPage_ncc.Location = new System.Drawing.Point(4, 39);
            this.tabPage_ncc.Name = "tabPage_ncc";
            this.tabPage_ncc.Size = new System.Drawing.Size(958, 459);
            this.tabPage_ncc.TabIndex = 3;
            this.tabPage_ncc.Text = "Quản Lý Nhà Cung Cấp";
            this.tabPage_ncc.Click += new System.EventHandler(this.tabPage4_Click);
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.dataGridView_ncc);
            this.groupBox6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox6.Location = new System.Drawing.Point(6, 214);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(948, 248);
            this.groupBox6.TabIndex = 22;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Danh sách nhà cung cấp";
            // 
            // dataGridView_ncc
            // 
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridView_ncc.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle9;
            this.dataGridView_ncc.BackgroundColor = System.Drawing.SystemColors.InactiveBorder;
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle10.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle10.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle10.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle10.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView_ncc.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle10;
            this.dataGridView_ncc.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle11.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle11.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle11.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle11.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView_ncc.DefaultCellStyle = dataGridViewCellStyle11;
            this.dataGridView_ncc.Location = new System.Drawing.Point(0, 21);
            this.dataGridView_ncc.Name = "dataGridView_ncc";
            this.dataGridView_ncc.Size = new System.Drawing.Size(948, 224);
            this.dataGridView_ncc.TabIndex = 0;
            this.dataGridView_ncc.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView_ncc_CellContentClick);
            // 
            // btnLuu_ncc
            // 
            this.btnLuu_ncc.Image = ((System.Drawing.Image)(resources.GetObject("btnLuu_ncc.Image")));
            this.btnLuu_ncc.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnLuu_ncc.Location = new System.Drawing.Point(647, 170);
            this.btnLuu_ncc.Name = "btnLuu_ncc";
            this.btnLuu_ncc.Size = new System.Drawing.Size(75, 38);
            this.btnLuu_ncc.TabIndex = 7;
            this.btnLuu_ncc.Text = "Lưu";
            this.btnLuu_ncc.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnLuu_ncc.UseVisualStyleBackColor = true;
            this.btnLuu_ncc.Click += new System.EventHandler(this.btnLuu_ncc_Click);
            // 
            // btnHuy_ncc
            // 
            this.btnHuy_ncc.Image = ((System.Drawing.Image)(resources.GetObject("btnHuy_ncc.Image")));
            this.btnHuy_ncc.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnHuy_ncc.Location = new System.Drawing.Point(508, 170);
            this.btnHuy_ncc.Name = "btnHuy_ncc";
            this.btnHuy_ncc.Size = new System.Drawing.Size(75, 38);
            this.btnHuy_ncc.TabIndex = 6;
            this.btnHuy_ncc.Text = "Hủy";
            this.btnHuy_ncc.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnHuy_ncc.UseVisualStyleBackColor = true;
            this.btnHuy_ncc.Click += new System.EventHandler(this.btnHuy_ncc_Click);
            // 
            // btnXoa_ncc
            // 
            this.btnXoa_ncc.Image = ((System.Drawing.Image)(resources.GetObject("btnXoa_ncc.Image")));
            this.btnXoa_ncc.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnXoa_ncc.Location = new System.Drawing.Point(360, 170);
            this.btnXoa_ncc.Name = "btnXoa_ncc";
            this.btnXoa_ncc.Size = new System.Drawing.Size(75, 38);
            this.btnXoa_ncc.TabIndex = 5;
            this.btnXoa_ncc.Text = "Xóa";
            this.btnXoa_ncc.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnXoa_ncc.UseVisualStyleBackColor = true;
            this.btnXoa_ncc.Click += new System.EventHandler(this.btnXoa_ncc_Click);
            // 
            // btnSua_ncc
            // 
            this.btnSua_ncc.Image = ((System.Drawing.Image)(resources.GetObject("btnSua_ncc.Image")));
            this.btnSua_ncc.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSua_ncc.Location = new System.Drawing.Point(209, 170);
            this.btnSua_ncc.Name = "btnSua_ncc";
            this.btnSua_ncc.Size = new System.Drawing.Size(75, 38);
            this.btnSua_ncc.TabIndex = 4;
            this.btnSua_ncc.Text = "Sửa";
            this.btnSua_ncc.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnSua_ncc.UseVisualStyleBackColor = true;
            this.btnSua_ncc.Click += new System.EventHandler(this.btnSua_ncc_Click);
            // 
            // btnThem_ncc
            // 
            this.btnThem_ncc.Image = ((System.Drawing.Image)(resources.GetObject("btnThem_ncc.Image")));
            this.btnThem_ncc.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnThem_ncc.Location = new System.Drawing.Point(72, 170);
            this.btnThem_ncc.Name = "btnThem_ncc";
            this.btnThem_ncc.Size = new System.Drawing.Size(75, 38);
            this.btnThem_ncc.TabIndex = 3;
            this.btnThem_ncc.Text = "Thêm";
            this.btnThem_ncc.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnThem_ncc.UseVisualStyleBackColor = true;
            this.btnThem_ncc.Click += new System.EventHandler(this.btnThem_ncc_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.txtTenncc_tk);
            this.groupBox3.Controls.Add(this.btnTimkiem_ncc);
            this.groupBox3.Controls.Add(this.label9);
            this.groupBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.Location = new System.Drawing.Point(679, 3);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(275, 147);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Tìm kiếm";
            // 
            // txtTenncc_tk
            // 
            this.txtTenncc_tk.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTenncc_tk.Location = new System.Drawing.Point(115, 38);
            this.txtTenncc_tk.Name = "txtTenncc_tk";
            this.txtTenncc_tk.Size = new System.Drawing.Size(154, 22);
            this.txtTenncc_tk.TabIndex = 12;
            // 
            // btnTimkiem_ncc
            // 
            this.btnTimkiem_ncc.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTimkiem_ncc.Image = ((System.Drawing.Image)(resources.GetObject("btnTimkiem_ncc.Image")));
            this.btnTimkiem_ncc.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnTimkiem_ncc.Location = new System.Drawing.Point(166, 84);
            this.btnTimkiem_ncc.Name = "btnTimkiem_ncc";
            this.btnTimkiem_ncc.Size = new System.Drawing.Size(103, 38);
            this.btnTimkiem_ncc.TabIndex = 6;
            this.btnTimkiem_ncc.Text = "Tìm Kiếm";
            this.btnTimkiem_ncc.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnTimkiem_ncc.UseVisualStyleBackColor = true;
            this.btnTimkiem_ncc.Click += new System.EventHandler(this.btnTimkiem_ncc_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(15, 44);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(63, 16);
            this.label9.TabIndex = 1;
            this.label9.Text = "Tên NCC";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.txtSDT_ncc);
            this.groupBox2.Controls.Add(this.txtDiachi_ncc);
            this.groupBox2.Controls.Add(this.txtTenNCC_ncc);
            this.groupBox2.Controls.Add(this.txtMaNCC_ncc);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Controls.Add(this.label15);
            this.groupBox2.Controls.Add(this.label16);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(5, 3);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(668, 147);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Nhập thông tin nhà cung cấp";
            // 
            // txtSDT_ncc
            // 
            this.txtSDT_ncc.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSDT_ncc.Location = new System.Drawing.Point(420, 100);
            this.txtSDT_ncc.Name = "txtSDT_ncc";
            this.txtSDT_ncc.Size = new System.Drawing.Size(154, 22);
            this.txtSDT_ncc.TabIndex = 11;
            // 
            // txtDiachi_ncc
            // 
            this.txtDiachi_ncc.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDiachi_ncc.Location = new System.Drawing.Point(420, 40);
            this.txtDiachi_ncc.Name = "txtDiachi_ncc";
            this.txtDiachi_ncc.Size = new System.Drawing.Size(226, 22);
            this.txtDiachi_ncc.TabIndex = 10;
            // 
            // txtTenNCC_ncc
            // 
            this.txtTenNCC_ncc.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTenNCC_ncc.Location = new System.Drawing.Point(151, 100);
            this.txtTenNCC_ncc.Name = "txtTenNCC_ncc";
            this.txtTenNCC_ncc.Size = new System.Drawing.Size(134, 22);
            this.txtTenNCC_ncc.TabIndex = 5;
            // 
            // txtMaNCC_ncc
            // 
            this.txtMaNCC_ncc.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMaNCC_ncc.Location = new System.Drawing.Point(151, 40);
            this.txtMaNCC_ncc.Name = "txtMaNCC_ncc";
            this.txtMaNCC_ncc.Size = new System.Drawing.Size(79, 22);
            this.txtMaNCC_ncc.TabIndex = 4;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(303, 102);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(86, 16);
            this.label13.TabIndex = 3;
            this.label13.Text = "Số điện thoại";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(303, 44);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(48, 16);
            this.label14.TabIndex = 2;
            this.label14.Text = "Địa chỉ";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(25, 102);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(115, 16);
            this.label15.TabIndex = 1;
            this.label15.Text = "Tên nhà cung cấp";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(25, 44);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(110, 16);
            this.label16.TabIndex = 0;
            this.label16.Text = "Mã nhà cung cấp";
            // 
            // tabPage5
            // 
            this.tabPage5.BackColor = System.Drawing.Color.PaleTurquoise;
            this.tabPage5.Controls.Add(this.groupBox9);
            this.tabPage5.Controls.Add(this.btnLuu_nv);
            this.tabPage5.Controls.Add(this.btnHuy_nv);
            this.tabPage5.Controls.Add(this.btnXoa_nv);
            this.tabPage5.Controls.Add(this.btnSua_nv);
            this.tabPage5.Controls.Add(this.btnThem_nv);
            this.tabPage5.Controls.Add(this.groupBox8);
            this.tabPage5.Controls.Add(this.groupBox7);
            this.tabPage5.Location = new System.Drawing.Point(4, 39);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Size = new System.Drawing.Size(958, 459);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "Quản Lý Nhân Viên";
            this.tabPage5.Click += new System.EventHandler(this.tabPage5_Click);
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.dataGridView_nv);
            this.groupBox9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox9.Location = new System.Drawing.Point(6, 214);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(948, 248);
            this.groupBox9.TabIndex = 23;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "Danh sách nhân viên";
            // 
            // dataGridView_nv
            // 
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridView_nv.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle12;
            this.dataGridView_nv.BackgroundColor = System.Drawing.SystemColors.InactiveBorder;
            dataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle13.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle13.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle13.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle13.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle13.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView_nv.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle13;
            this.dataGridView_nv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle14.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle14.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle14.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle14.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle14.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView_nv.DefaultCellStyle = dataGridViewCellStyle14;
            this.dataGridView_nv.Location = new System.Drawing.Point(0, 21);
            this.dataGridView_nv.Name = "dataGridView_nv";
            this.dataGridView_nv.Size = new System.Drawing.Size(948, 224);
            this.dataGridView_nv.TabIndex = 0;
            this.dataGridView_nv.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView_nv_CellContentClick);
            // 
            // btnLuu_nv
            // 
            this.btnLuu_nv.Image = ((System.Drawing.Image)(resources.GetObject("btnLuu_nv.Image")));
            this.btnLuu_nv.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnLuu_nv.Location = new System.Drawing.Point(635, 170);
            this.btnLuu_nv.Name = "btnLuu_nv";
            this.btnLuu_nv.Size = new System.Drawing.Size(75, 38);
            this.btnLuu_nv.TabIndex = 12;
            this.btnLuu_nv.Text = "Lưu";
            this.btnLuu_nv.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnLuu_nv.UseVisualStyleBackColor = true;
            this.btnLuu_nv.Click += new System.EventHandler(this.btnLuu_nv_Click);
            // 
            // btnHuy_nv
            // 
            this.btnHuy_nv.Image = ((System.Drawing.Image)(resources.GetObject("btnHuy_nv.Image")));
            this.btnHuy_nv.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnHuy_nv.Location = new System.Drawing.Point(496, 170);
            this.btnHuy_nv.Name = "btnHuy_nv";
            this.btnHuy_nv.Size = new System.Drawing.Size(75, 38);
            this.btnHuy_nv.TabIndex = 11;
            this.btnHuy_nv.Text = "Hủy";
            this.btnHuy_nv.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnHuy_nv.UseVisualStyleBackColor = true;
            this.btnHuy_nv.Click += new System.EventHandler(this.btnHuy_nv_Click);
            // 
            // btnXoa_nv
            // 
            this.btnXoa_nv.Image = ((System.Drawing.Image)(resources.GetObject("btnXoa_nv.Image")));
            this.btnXoa_nv.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnXoa_nv.Location = new System.Drawing.Point(348, 170);
            this.btnXoa_nv.Name = "btnXoa_nv";
            this.btnXoa_nv.Size = new System.Drawing.Size(75, 38);
            this.btnXoa_nv.TabIndex = 10;
            this.btnXoa_nv.Text = "Xóa";
            this.btnXoa_nv.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnXoa_nv.UseVisualStyleBackColor = true;
            this.btnXoa_nv.Click += new System.EventHandler(this.btnXoa_nv_Click);
            // 
            // btnSua_nv
            // 
            this.btnSua_nv.Image = ((System.Drawing.Image)(resources.GetObject("btnSua_nv.Image")));
            this.btnSua_nv.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSua_nv.Location = new System.Drawing.Point(197, 170);
            this.btnSua_nv.Name = "btnSua_nv";
            this.btnSua_nv.Size = new System.Drawing.Size(75, 38);
            this.btnSua_nv.TabIndex = 9;
            this.btnSua_nv.Text = "Sửa";
            this.btnSua_nv.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnSua_nv.UseVisualStyleBackColor = true;
            this.btnSua_nv.Click += new System.EventHandler(this.btnSua_nv_Click);
            // 
            // btnThem_nv
            // 
            this.btnThem_nv.Image = ((System.Drawing.Image)(resources.GetObject("btnThem_nv.Image")));
            this.btnThem_nv.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnThem_nv.Location = new System.Drawing.Point(60, 170);
            this.btnThem_nv.Name = "btnThem_nv";
            this.btnThem_nv.Size = new System.Drawing.Size(75, 38);
            this.btnThem_nv.TabIndex = 8;
            this.btnThem_nv.Text = "Thêm";
            this.btnThem_nv.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnThem_nv.UseVisualStyleBackColor = true;
            this.btnThem_nv.Click += new System.EventHandler(this.btnThem_nv_Click);
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.txtTennv_tk);
            this.groupBox8.Controls.Add(this.btnTimkiem_nv);
            this.groupBox8.Controls.Add(this.label12);
            this.groupBox8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox8.Location = new System.Drawing.Point(686, 6);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(268, 147);
            this.groupBox8.TabIndex = 3;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Tìm kiếm";
            // 
            // txtTennv_tk
            // 
            this.txtTennv_tk.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTennv_tk.Location = new System.Drawing.Point(108, 40);
            this.txtTennv_tk.Name = "txtTennv_tk";
            this.txtTennv_tk.Size = new System.Drawing.Size(154, 22);
            this.txtTennv_tk.TabIndex = 12;
            // 
            // btnTimkiem_nv
            // 
            this.btnTimkiem_nv.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTimkiem_nv.Image = ((System.Drawing.Image)(resources.GetObject("btnTimkiem_nv.Image")));
            this.btnTimkiem_nv.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnTimkiem_nv.Location = new System.Drawing.Point(155, 85);
            this.btnTimkiem_nv.Name = "btnTimkiem_nv";
            this.btnTimkiem_nv.Size = new System.Drawing.Size(100, 37);
            this.btnTimkiem_nv.TabIndex = 6;
            this.btnTimkiem_nv.Text = "Tìm Kiếm";
            this.btnTimkiem_nv.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnTimkiem_nv.UseVisualStyleBackColor = true;
            this.btnTimkiem_nv.Click += new System.EventHandler(this.btnTimkiem_nv_Click);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(15, 44);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(92, 16);
            this.label12.TabIndex = 1;
            this.label12.Text = "Tên nhân viên";
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.txtSDT_nv);
            this.groupBox7.Controls.Add(this.txtNgaysinh_nv);
            this.groupBox7.Controls.Add(this.chkGioitinh_nv);
            this.groupBox7.Controls.Add(this.txtDiachi_nv);
            this.groupBox7.Controls.Add(this.label17);
            this.groupBox7.Controls.Add(this.label18);
            this.groupBox7.Controls.Add(this.txtTennhanvien_nv);
            this.groupBox7.Controls.Add(this.txtManhanvien_nv);
            this.groupBox7.Controls.Add(this.label19);
            this.groupBox7.Controls.Add(this.label20);
            this.groupBox7.Controls.Add(this.label21);
            this.groupBox7.Controls.Add(this.label22);
            this.groupBox7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox7.Location = new System.Drawing.Point(6, 6);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(675, 147);
            this.groupBox7.TabIndex = 1;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Nhập thông tin nhân viên";
            // 
            // txtSDT_nv
            // 
            this.txtSDT_nv.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSDT_nv.Location = new System.Drawing.Point(560, 32);
            this.txtSDT_nv.Name = "txtSDT_nv";
            this.txtSDT_nv.Size = new System.Drawing.Size(100, 22);
            this.txtSDT_nv.TabIndex = 14;
            // 
            // txtNgaysinh_nv
            // 
            this.txtNgaysinh_nv.Location = new System.Drawing.Point(342, 85);
            this.txtNgaysinh_nv.Mask = "00/00/0000";
            this.txtNgaysinh_nv.Name = "txtNgaysinh_nv";
            this.txtNgaysinh_nv.Size = new System.Drawing.Size(100, 22);
            this.txtNgaysinh_nv.TabIndex = 13;
            this.txtNgaysinh_nv.ValidatingType = typeof(System.DateTime);
            this.txtNgaysinh_nv.MaskInputRejected += new System.Windows.Forms.MaskInputRejectedEventHandler(this.txtNgaysinh_nv_MaskInputRejected);
            // 
            // chkGioitinh_nv
            // 
            this.chkGioitinh_nv.AutoSize = true;
            this.chkGioitinh_nv.Location = new System.Drawing.Point(352, 37);
            this.chkGioitinh_nv.Name = "chkGioitinh_nv";
            this.chkGioitinh_nv.Size = new System.Drawing.Size(56, 20);
            this.chkGioitinh_nv.TabIndex = 12;
            this.chkGioitinh_nv.Text = "Nam";
            this.chkGioitinh_nv.UseVisualStyleBackColor = true;
            // 
            // txtDiachi_nv
            // 
            this.txtDiachi_nv.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDiachi_nv.Location = new System.Drawing.Point(560, 85);
            this.txtDiachi_nv.Name = "txtDiachi_nv";
            this.txtDiachi_nv.Size = new System.Drawing.Size(100, 22);
            this.txtDiachi_nv.TabIndex = 9;
            this.txtDiachi_nv.TextChanged += new System.EventHandler(this.txtDiachi_nv_TextChanged);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(467, 88);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(48, 16);
            this.label17.TabIndex = 7;
            this.label17.Text = "Địa chỉ";
            this.label17.Click += new System.EventHandler(this.label17_Click);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(454, 40);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(86, 16);
            this.label18.TabIndex = 6;
            this.label18.Text = "Số điện thoại";
            // 
            // txtTennhanvien_nv
            // 
            this.txtTennhanvien_nv.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTennhanvien_nv.Location = new System.Drawing.Point(111, 89);
            this.txtTennhanvien_nv.Name = "txtTennhanvien_nv";
            this.txtTennhanvien_nv.Size = new System.Drawing.Size(134, 22);
            this.txtTennhanvien_nv.TabIndex = 5;
            this.txtTennhanvien_nv.TextChanged += new System.EventHandler(this.txtTennhanvien_nv_TextChanged);
            // 
            // txtManhanvien_nv
            // 
            this.txtManhanvien_nv.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtManhanvien_nv.Location = new System.Drawing.Point(111, 39);
            this.txtManhanvien_nv.Name = "txtManhanvien_nv";
            this.txtManhanvien_nv.Size = new System.Drawing.Size(79, 22);
            this.txtManhanvien_nv.TabIndex = 4;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(259, 88);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(68, 16);
            this.label19.TabIndex = 3;
            this.label19.Text = "Ngày sinh";
            this.label19.Click += new System.EventHandler(this.label19_Click);
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(259, 38);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(55, 16);
            this.label20.TabIndex = 2;
            this.label20.Text = "Giới tính";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(18, 91);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(92, 16);
            this.label21.TabIndex = 1;
            this.label21.Text = "Tên nhân viên";
            this.label21.Click += new System.EventHandler(this.label21_Click);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(18, 43);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(87, 16);
            this.label22.TabIndex = 0;
            this.label22.Text = "Mã nhân viên";
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.panel2);
            this.tabPage4.Controls.Add(this.panel1);
            this.tabPage4.Location = new System.Drawing.Point(4, 39);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(958, 459);
            this.tabPage4.TabIndex = 5;
            this.tabPage4.Text = "Thống kê";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.PaleTurquoise;
            this.panel2.Controls.Add(this.txtNgay_hh);
            this.panel2.Controls.Add(this.label53);
            this.panel2.Controls.Add(this.btnTklai);
            this.panel2.Controls.Add(this.dgvhang_tk);
            this.panel2.Controls.Add(this.txtThang_hh);
            this.panel2.Controls.Add(this.label56);
            this.panel2.Controls.Add(this.label57);
            this.panel2.Controls.Add(this.btnThongke_hh);
            this.panel2.Controls.Add(this.cboNam_hh);
            this.panel2.Controls.Add(this.label60);
            this.panel2.Location = new System.Drawing.Point(412, 3);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(543, 453);
            this.panel2.TabIndex = 27;
            // 
            // btnTklai
            // 
            this.btnTklai.BackColor = System.Drawing.Color.IndianRed;
            this.btnTklai.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTklai.Location = new System.Drawing.Point(410, 107);
            this.btnTklai.Name = "btnTklai";
            this.btnTklai.Size = new System.Drawing.Size(107, 38);
            this.btnTklai.TabIndex = 24;
            this.btnTklai.Text = "Chọn lại";
            this.btnTklai.UseVisualStyleBackColor = false;
            this.btnTklai.Click += new System.EventHandler(this.btnTklai_Click);
            // 
            // dgvhang_tk
            // 
            this.dgvhang_tk.BackgroundColor = System.Drawing.SystemColors.InactiveBorder;
            dataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle15.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle15.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle15.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle15.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle15.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvhang_tk.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle15;
            this.dgvhang_tk.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle16.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle16.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle16.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle16.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle16.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle16.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvhang_tk.DefaultCellStyle = dataGridViewCellStyle16;
            this.dgvhang_tk.Location = new System.Drawing.Point(3, 207);
            this.dgvhang_tk.Name = "dgvhang_tk";
            this.dgvhang_tk.Size = new System.Drawing.Size(537, 246);
            this.dgvhang_tk.TabIndex = 23;
            // 
            // txtThang_hh
            // 
            this.txtThang_hh.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtThang_hh.Location = new System.Drawing.Point(214, 115);
            this.txtThang_hh.Name = "txtThang_hh";
            this.txtThang_hh.Size = new System.Drawing.Size(127, 22);
            this.txtThang_hh.TabIndex = 22;
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label56.Location = new System.Drawing.Point(38, 121);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(137, 16);
            this.label56.TabIndex = 21;
            this.label56.Text = "Nhập tháng(bắt buộc)";
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label57.Location = new System.Drawing.Point(38, 78);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(131, 16);
            this.label57.TabIndex = 20;
            this.label57.Text = "Chọn năm (bắt buộc)";
            // 
            // btnThongke_hh
            // 
            this.btnThongke_hh.BackColor = System.Drawing.Color.IndianRed;
            this.btnThongke_hh.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnThongke_hh.Location = new System.Drawing.Point(410, 63);
            this.btnThongke_hh.Name = "btnThongke_hh";
            this.btnThongke_hh.Size = new System.Drawing.Size(107, 38);
            this.btnThongke_hh.TabIndex = 15;
            this.btnThongke_hh.Text = "Thống kê";
            this.btnThongke_hh.UseVisualStyleBackColor = false;
            this.btnThongke_hh.Click += new System.EventHandler(this.btnThongke_hh_Click);
            // 
            // cboNam_hh
            // 
            this.cboNam_hh.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboNam_hh.FormattingEnabled = true;
            this.cboNam_hh.Items.AddRange(new object[] {
            "2019",
            "2020",
            "2021",
            "2022",
            "2023"});
            this.cboNam_hh.Location = new System.Drawing.Point(214, 72);
            this.cboNam_hh.Name = "cboNam_hh";
            this.cboNam_hh.Size = new System.Drawing.Size(127, 24);
            this.cboNam_hh.TabIndex = 14;
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label60.Location = new System.Drawing.Point(165, 26);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(224, 16);
            this.label60.TabIndex = 13;
            this.label60.Text = "Thống kê mặt hàng theo ngày, tháng";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.PaleTurquoise;
            this.panel1.Controls.Add(this.txtNgay);
            this.panel1.Controls.Add(this.label49);
            this.panel1.Controls.Add(this.btnChonlai);
            this.panel1.Controls.Add(this.label51);
            this.panel1.Controls.Add(this.label52);
            this.panel1.Controls.Add(this.lblLoi);
            this.panel1.Controls.Add(this.lblTien);
            this.panel1.Controls.Add(this.txtThang);
            this.panel1.Controls.Add(this.label50);
            this.panel1.Controls.Add(this.label45);
            this.panel1.Controls.Add(this.label48);
            this.panel1.Controls.Add(this.label47);
            this.panel1.Controls.Add(this.btnThongKe);
            this.panel1.Controls.Add(this.cboNam);
            this.panel1.Controls.Add(this.label46);
            this.panel1.Location = new System.Drawing.Point(3, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(403, 453);
            this.panel1.TabIndex = 9;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // btnChonlai
            // 
            this.btnChonlai.BackColor = System.Drawing.Color.IndianRed;
            this.btnChonlai.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnChonlai.Location = new System.Drawing.Point(52, 221);
            this.btnChonlai.Name = "btnChonlai";
            this.btnChonlai.Size = new System.Drawing.Size(127, 38);
            this.btnChonlai.TabIndex = 27;
            this.btnChonlai.Text = "Chọn lại";
            this.btnChonlai.UseVisualStyleBackColor = false;
            this.btnChonlai.Click += new System.EventHandler(this.btnChonlai_Click);
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label51.Location = new System.Drawing.Point(305, 362);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(36, 16);
            this.label51.TabIndex = 26;
            this.label51.Text = "VNĐ";
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label52.Location = new System.Drawing.Point(305, 305);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(36, 16);
            this.label52.TabIndex = 25;
            this.label52.Text = "VNĐ";
            // 
            // lblLoi
            // 
            this.lblLoi.AutoSize = true;
            this.lblLoi.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLoi.ForeColor = System.Drawing.SystemColors.Highlight;
            this.lblLoi.Location = new System.Drawing.Point(211, 362);
            this.lblLoi.Name = "lblLoi";
            this.lblLoi.Size = new System.Drawing.Size(0, 16);
            this.lblLoi.TabIndex = 24;
            // 
            // lblTien
            // 
            this.lblTien.AutoSize = true;
            this.lblTien.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTien.ForeColor = System.Drawing.SystemColors.Highlight;
            this.lblTien.Location = new System.Drawing.Point(211, 304);
            this.lblTien.Name = "lblTien";
            this.lblTien.Size = new System.Drawing.Size(0, 16);
            this.lblTien.TabIndex = 23;
            // 
            // txtThang
            // 
            this.txtThang.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtThang.Location = new System.Drawing.Point(214, 115);
            this.txtThang.Name = "txtThang";
            this.txtThang.Size = new System.Drawing.Size(127, 22);
            this.txtThang.TabIndex = 22;
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label50.Location = new System.Drawing.Point(38, 121);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(137, 16);
            this.label50.TabIndex = 21;
            this.label50.Text = "Nhập tháng(bắt buộc)";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label45.Location = new System.Drawing.Point(38, 78);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(131, 16);
            this.label45.TabIndex = 20;
            this.label45.Text = "Chọn năm (bắt buộc)";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label48.Location = new System.Drawing.Point(38, 362);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(65, 16);
            this.label48.TabIndex = 18;
            this.label48.Text = "Lợi nhuận";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label47.Location = new System.Drawing.Point(38, 304);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(141, 16);
            this.label47.TabIndex = 16;
            this.label47.Text = "Tổng số tiền bán được";
            // 
            // btnThongKe
            // 
            this.btnThongKe.BackColor = System.Drawing.Color.IndianRed;
            this.btnThongKe.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnThongKe.Location = new System.Drawing.Point(214, 221);
            this.btnThongKe.Name = "btnThongKe";
            this.btnThongKe.Size = new System.Drawing.Size(127, 38);
            this.btnThongKe.TabIndex = 15;
            this.btnThongKe.Text = "Thống kê";
            this.btnThongKe.UseVisualStyleBackColor = false;
            this.btnThongKe.Click += new System.EventHandler(this.btnThongKe_Click);
            // 
            // cboNam
            // 
            this.cboNam.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboNam.FormattingEnabled = true;
            this.cboNam.Items.AddRange(new object[] {
            "2019",
            "2020",
            "2021",
            "2022",
            "2023"});
            this.cboNam.Location = new System.Drawing.Point(214, 72);
            this.cboNam.Name = "cboNam";
            this.cboNam.Size = new System.Drawing.Size(127, 24);
            this.cboNam.TabIndex = 14;
            this.cboNam.DropDown += new System.EventHandler(this.cboNam_DropDown);
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label46.Location = new System.Drawing.Point(77, 26);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(227, 16);
            this.label46.TabIndex = 13;
            this.label46.Text = "Thống kê doanh thu theo ngày, tháng";
            // 
            // button13
            // 
            this.button13.Location = new System.Drawing.Point(146, 95);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(75, 27);
            this.button13.TabIndex = 6;
            this.button13.Text = "Tìm";
            this.button13.UseVisualStyleBackColor = true;
            // 
            // textBox12
            // 
            this.textBox12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox12.Location = new System.Drawing.Point(146, 41);
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(109, 22);
            this.textBox12.TabIndex = 5;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(15, 44);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(110, 16);
            this.label11.TabIndex = 1;
            this.label11.Text = "Mã nhà cung cấp";
            // 
            // dataGridView3
            // 
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.Location = new System.Drawing.Point(0, 21);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.Size = new System.Drawing.Size(949, 224);
            this.dataGridView3.TabIndex = 0;
            // 
            // dataGridView4
            // 
            this.dataGridView4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView4.Location = new System.Drawing.Point(0, 21);
            this.dataGridView4.Name = "dataGridView4";
            this.dataGridView4.Size = new System.Drawing.Size(949, 224);
            this.dataGridView4.TabIndex = 0;
            // 
            // dataGridView5
            // 
            this.dataGridView5.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView5.Location = new System.Drawing.Point(0, 21);
            this.dataGridView5.Name = "dataGridView5";
            this.dataGridView5.Size = new System.Drawing.Size(949, 224);
            this.dataGridView5.TabIndex = 0;
            // 
            // button26
            // 
            this.button26.Location = new System.Drawing.Point(146, 95);
            this.button26.Name = "button26";
            this.button26.Size = new System.Drawing.Size(75, 27);
            this.button26.TabIndex = 6;
            this.button26.Text = "Tìm";
            this.button26.UseVisualStyleBackColor = true;
            // 
            // textBox32
            // 
            this.textBox32.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox32.Location = new System.Drawing.Point(146, 41);
            this.textBox32.Name = "textBox32";
            this.textBox32.Size = new System.Drawing.Size(109, 22);
            this.textBox32.TabIndex = 5;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label37.Location = new System.Drawing.Point(15, 44);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(110, 16);
            this.label37.TabIndex = 1;
            this.label37.Text = "Mã nhà cung cấp";
            // 
            // txtNgay
            // 
            this.txtNgay.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNgay.Location = new System.Drawing.Point(214, 167);
            this.txtNgay.Name = "txtNgay";
            this.txtNgay.Size = new System.Drawing.Size(127, 22);
            this.txtNgay.TabIndex = 29;
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label49.Location = new System.Drawing.Point(38, 173);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(74, 16);
            this.label49.TabIndex = 28;
            this.label49.Text = "Nhập ngày";
            // 
            // txtNgay_hh
            // 
            this.txtNgay_hh.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNgay_hh.Location = new System.Drawing.Point(214, 161);
            this.txtNgay_hh.Name = "txtNgay_hh";
            this.txtNgay_hh.Size = new System.Drawing.Size(127, 22);
            this.txtNgay_hh.TabIndex = 31;
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label53.Location = new System.Drawing.Point(38, 167);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(74, 16);
            this.label53.TabIndex = 30;
            this.label53.Text = "Nhập ngày";
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(966, 501);
            this.Controls.Add(this.tabControl1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "frmMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Quản lý bán hàng";
            this.Load += new System.EventHandler(this.frmMain_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_hh)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.groupBox11.ResumeLayout(false);
            this.groupBox11.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_hd)).EndInit();
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            this.tabPage_ncc.ResumeLayout(false);
            this.groupBox6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_ncc)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.tabPage5.ResumeLayout(false);
            this.groupBox9.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_nv)).EndInit();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvhang_tk)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView5)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage_ncc;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtGiaban_hh;
        private System.Windows.Forms.TextBox txtSoluong_hh;
        private System.Windows.Forms.TextBox txtGianhap_hh;
        private System.Windows.Forms.TextBox txtDonvitinh_hh;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtTenhang_hh;
        private System.Windows.Forms.TextBox txtMahang_hh;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox txtSDT_ncc;
        private System.Windows.Forms.TextBox txtDiachi_ncc;
        private System.Windows.Forms.TextBox txtTenNCC_ncc;
        private System.Windows.Forms.TextBox txtMaNCC_ncc;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button btnLuu_ncc;
        private System.Windows.Forms.Button btnHuy_ncc;
        private System.Windows.Forms.Button btnXoa_ncc;
        private System.Windows.Forms.Button btnSua_ncc;
        private System.Windows.Forms.Button btnThem_ncc;
        private System.Windows.Forms.Button btnTimkiem_ncc;
        private System.Windows.Forms.Button btnLuu_hh;
        private System.Windows.Forms.Button btnHuy_hh;
        private System.Windows.Forms.Button btnSua_hh;
        private System.Windows.Forms.Button btnXoa_hh;
        private System.Windows.Forms.Button btnThem_hh;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Button btnTimkiem_hh;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.DataGridView dataGridView_hh;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.DataGridView dataGridView_ncc;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.Button btnTimkiem_nv;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.TextBox txtDiachi_nv;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox txtTennhanvien_nv;
        private System.Windows.Forms.TextBox txtManhanvien_nv;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.DataGridView dataGridView3;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.DataGridView dataGridView_nv;
        private System.Windows.Forms.Button btnLuu_nv;
        private System.Windows.Forms.Button btnHuy_nv;
        private System.Windows.Forms.Button btnXoa_nv;
        private System.Windows.Forms.Button btnSua_nv;
        private System.Windows.Forms.Button btnThem_nv;
        private System.Windows.Forms.DataGridView dataGridView4;
        private System.Windows.Forms.DataGridView dataGridView5;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.TextBox txtTennhanvien_hd;
        private System.Windows.Forms.TextBox txtNgayban_hd;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.ComboBox cboManhanvien_hd;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.TextBox txtGiamgia_hd;
        private System.Windows.Forms.TextBox txtThanhtien_hd;
        private System.Windows.Forms.TextBox txtDongia_hd;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.ComboBox cboMahanghoa_hd;
        private System.Windows.Forms.TextBox txtTenhang_hd;
        private System.Windows.Forms.Button btnIn_hd;
        private System.Windows.Forms.Button btnLuu_hd;
        private System.Windows.Forms.DataGridView dataGridView_hd;
        private System.Windows.Forms.Button btnThem_hd;
        private System.Windows.Forms.Button btnHuy_hd;
        private System.Windows.Forms.Button btnXoa_hd;
        private System.Windows.Forms.Button button26;
        private System.Windows.Forms.TextBox textBox32;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label lbltongtienbangchu;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.TextBox txtTongTien_hd;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.ComboBox cboManhacc_hh;
        private System.Windows.Forms.TextBox txtGhichu_hh;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lblBangchu;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.CheckBox chkGioitinh_nv;
        private System.Windows.Forms.MaskedTextBox txtNgaysinh_nv;
        private System.Windows.Forms.TextBox txtSDT_nv;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox txtTenhh_tk;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.Button btnTimkiem_hd;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label38;
        public System.Windows.Forms.TextBox txtMahoadon_hd;
        public System.Windows.Forms.TextBox txtSoluong_hd;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox txtThang;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Button btnThongKe;
        private System.Windows.Forms.ComboBox cboNam;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label lblLoi;
        private System.Windows.Forms.Label lblTien;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.DataGridView dgvhang_tk;
        private System.Windows.Forms.TextBox txtThang_hh;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.Button btnThongke_hh;
        private System.Windows.Forms.ComboBox cboNam_hh;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.TextBox txtTenncc_tk;
        private System.Windows.Forms.TextBox txtTennv_tk;
        private System.Windows.Forms.Button btnChonlai;
        private System.Windows.Forms.Button btnTklai;
        private System.Windows.Forms.TextBox txtNgay;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.TextBox txtNgay_hh;
        private System.Windows.Forms.Label label53;
    }
}