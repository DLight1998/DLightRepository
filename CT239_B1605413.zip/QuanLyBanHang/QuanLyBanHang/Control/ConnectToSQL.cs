﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms; 
namespace QuanLyBanHang.Control
{
    class ConnectToSQL
    {
        public static SqlConnection con;  //Khai báo đối tượng kết nối        

        public static void Connect()
        {
            con = new SqlConnection();   //Khởi tạo đối tượng
            con.ConnectionString = @"Data Source = QUANG\SQLEXPRESS; Initial Catalog = QLBanHang; Persist Security Info = True; User ID = sa; Password = sa2008";
            con.Open();                  //Mở kết nối
            //Kiểm tra kết nối
            if (con.State == ConnectionState.Open)
                Console.Write("Kết nối thành công");
            else MessageBox.Show("Không thể kết nối với dữ liệu");

        }
        public static void Disconnect()
        {
            if (con.State == ConnectionState.Open)
            {
                con.Close();   	//Đóng kết nối
                con.Dispose(); 	//Giải phóng tài nguyên
                con = null;
            }
        }
    }
}
